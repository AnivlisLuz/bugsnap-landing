#!/usr/bin/env python3
"""
BugSnap Icon Generator — Dark beetle silhouette on bright green background.
Key design: DARK body (near-black green) on bright green gradient = readable bug silhouette.
Pure Python stdlib only.
"""

import os, math, struct, zlib

ICONS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icons')

def write_png(path, pixels, w, h):
    def chunk(name, data):
        body = name + data
        return struct.pack('>I', len(data)) + body + struct.pack('>I', zlib.crc32(body) & 0xffffffff)
    raw = b''
    for row in pixels:
        raw += b'\x00'
        for (r,g,b,a) in row:
            raw += bytes([r,g,b,a])
    ihdr = struct.pack('>II', w, h) + bytes([8, 6, 0, 0, 0])
    data = (b'\x89PNG\r\n\x1a\n'
            + chunk(b'IHDR', ihdr)
            + chunk(b'IDAT', zlib.compress(raw, 9))
            + chunk(b'IEND', b''))
    with open(path, 'wb') as f:
        f.write(data)

def lerp_color(a, b, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(a[i] + t*(b[i]-a[i])) for i in range(3))

def in_rounded_rect(px, py, x1, y1, x2, y2, r):
    cx, cy = px+0.5, py+0.5
    if cx<x1 or cx>x2 or cy<y1 or cy>y2: return False
    if cx<x1+r and cy<y1+r: return (cx-x1-r)**2+(cy-y1-r)**2<=r*r
    if cx>x2-r and cy<y1+r: return (cx-x2+r)**2+(cy-y1-r)**2<=r*r
    if cx<x1+r and cy>y2-r: return (cx-x1-r)**2+(cy-y2+r)**2<=r*r
    if cx>x2-r and cy>y2-r: return (cx-x2+r)**2+(cy-y2+r)**2<=r*r
    return True

def paint_circle(pixels, cx, cy, r, color, W, H):
    for dy in range(-int(r)-2, int(r)+3):
        for dx in range(-int(r)-2, int(r)+3):
            nx, ny = int(cx-0.5)+dx, int(cy-0.5)+dy
            if 0<=nx<W and 0<=ny<H:
                if (nx+0.5-cx)**2+(ny+0.5-cy)**2<=r*r:
                    pixels[ny][nx] = color+(255,)

def paint_ellipse(pixels, ex, ey, rx, ry, color, W, H):
    for y in range(max(0,int(ey-ry)-1), min(H,int(ey+ry)+2)):
        for x in range(max(0,int(ex-rx)-1), min(W,int(ex+rx)+2)):
            if ((x+0.5-ex)/rx)**2+((y+0.5-ey)/ry)**2<=1.0:
                pixels[y][x] = color+(255,)

def paint_line(pixels, x0, y0, x1, y1, color, thick, W, H):
    steps = int(max(abs(x1-x0), abs(y1-y0))*3)+1
    ir = int(thick)+2
    seen = set()
    for i in range(steps+1):
        t=i/steps; lx=x0+t*(x1-x0); ly=y0+t*(y1-y0)
        for dy in range(-ir,ir+1):
            for dx in range(-ir,ir+1):
                nx,ny=int(lx)+dx,int(ly)+dy
                if (nx,ny) in seen: continue
                seen.add((nx,ny))
                if 0<=nx<W and 0<=ny<H:
                    if (nx+0.5-lx)**2+(ny+0.5-ly)**2<=thick*thick:
                        pixels[ny][nx] = color+(255,)

def oval_x(by, bry, brx, y):
    d = y - by
    return brx * math.sqrt(max(0.0, 1.0-(d/bry)**2)) if abs(d) < bry else 0.0

def generate(size):
    W = H = size
    pixels = [[(0,0,0,0)]*W for _ in range(H)]

    # ── Background: bright green gradient rounded rect ─────────────────────
    pad = max(1.0, size*0.04); corner = size*0.22
    for y in range(H):
        for x in range(W):
            if in_rounded_rect(x, y, pad, pad, size-pad, size-pad, corner):
                t = (y+0.5-pad) / (size-2*pad)
                pixels[y][x] = lerp_color((4,55,38),(16,185,129), t) + (255,)

    cx = W / 2
    DARK  = (8, 22, 12)      # very dark green — bug body
    WHITE = (255, 255, 255)  # legs & antennae
    SHINE = (35, 90, 50)     # slightly lighter for wing gloss

    # ── Bug body: narrow vertical oval, dark, lower-center ─────────────────
    bx = cx
    by  = H * 0.610
    brx = size * 0.165
    bry = size * 0.265
    body_top = by - bry

    # ── LEGS — white, drawn BEFORE body (body covers roots) ────────────────
    leg_thick = max(1.5, size * 0.045)
    leg_len   = size * 0.255

    #  (y_along_body, lateral_extension, vertical_drop)
    leg_data = [
        (by - bry*0.45,  leg_len,        -size*0.090),  # front — angles up
        (by,             leg_len*1.05,    size*0.010),   # middle — nearly flat
        (by + bry*0.42,  leg_len*0.95,    size*0.095),  # rear  — angles down
    ]
    for (ly, ldx, ldy) in leg_data:
        ex = oval_x(by, bry, brx, ly) * 0.85
        if ex <= 0: continue
        tip_x_l = cx - ex - ldx
        tip_y   = ly + ldy
        tip_x_r = cx + ex + ldx
        paint_line(pixels, cx-ex, ly, tip_x_l, tip_y, WHITE, leg_thick, W, H)
        paint_line(pixels, cx+ex, ly, tip_x_r, tip_y, WHITE, leg_thick, W, H)

    # ── ANTENNAE — white, straight lines up-and-outward with round tips ────
    ant_thick = max(1.0, size * 0.032)
    tip_r     = max(1.8, size * 0.055)

    # Tips: high up, slightly outside body width → clearly antennae not ears
    tip_spread = size * 0.195
    tip_top    = size * 0.060

    # Roots: near top of body
    root_y = body_top + bry * 0.12
    root_x = oval_x(by, bry, brx, root_y) * 0.72

    paint_circle(pixels, cx - tip_spread, tip_top, tip_r, WHITE, W, H)
    paint_circle(pixels, cx + tip_spread, tip_top, tip_r, WHITE, W, H)
    paint_line(pixels, cx-root_x, root_y, cx-tip_spread, tip_top, WHITE, ant_thick, W, H)
    paint_line(pixels, cx+root_x, root_y, cx+tip_spread, tip_top, WHITE, ant_thick, W, H)

    # ── BODY: dark oval painted over leg/antenna roots ─────────────────────
    paint_ellipse(pixels, bx, by, brx, bry, DARK, W, H)

    # ── HEAD: small dark circle just above body ─────────────────────────────
    head_y = body_top - size * 0.008
    head_r = size * 0.068
    paint_circle(pixels, cx, head_y, head_r, DARK, W, H)

    # ── WING DETAILS: light lines on dark body (≥40px only) ────────────────
    if size >= 40:
        seg = max(0.6, size * 0.016)
        # Center division line (elytra split)
        paint_line(pixels, bx, body_top + bry*0.20,
                            bx, by + bry*0.85, SHINE, seg, W, H)
        # Horizontal segment lines
        for fr in (0.28, 0.58):
            sy = body_top + fr * 2 * bry
            sx = oval_x(by, bry, brx, sy) * 0.84
            if sx:
                paint_line(pixels, bx-sx, sy, bx+sx, sy, SHINE, seg, W, H)

    return pixels

os.makedirs(ICONS_DIR, exist_ok=True)
for size in [16, 48, 128]:
    path = os.path.join(ICONS_DIR, f'icon{size}.png')
    write_png(path, generate(size), size, size)
    print(f'✅  icon{size}.png  ({size}×{size} px)')
print(f'\nIcons saved to: {ICONS_DIR}')
