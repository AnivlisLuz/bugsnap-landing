// popup.js — BugSnap main logic
// Handles: screenshot capture, console error collection, Claude AI analysis, Azure DevOps export

const PROXY_URL    = 'https://bugsnap-proxy.luzchoquej.workers.dev/analyze';
const CLAUDE_MODEL = 'claude-sonnet-4-6';


let capturedData = {
  screenshot: null,   // base64 data URL
  url: '',
  browser: '',
  os: '',
  resolution: '',
  viewport: '',
  consoleLogs: [],    // all captured log entries (log/info/warn/error/uncaught/promise)
  timestamp: ''
};

let generatedReport = null; // { markdown, title, severity }

// ── Auth state ────────────────────────────────────────
let currentToken = null;

async function getAuthToken(interactive = false) {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive }, (token) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        currentToken = token;
        resolve(token);
      }
    });
  });
}

async function signOut() {
  if (currentToken) {
    // Revoke the token with Google
    try {
      await fetch(`https://accounts.google.com/o/oauth2/revoke?token=${currentToken}`);
    } catch (_) {}
    // Remove cached token from Chrome
    chrome.identity.removeCachedAuthToken({ token: currentToken }, () => {});
    currentToken = null;
  }
  showAuthGate();
}

function showAuthGate() {
  document.getElementById('authSection').classList.remove('hidden');
  document.getElementById('captureSection').classList.add('hidden');
  document.getElementById('manualFormSection').classList.add('hidden');
  document.getElementById('reportSection').classList.add('hidden');
  document.getElementById('actionBar').classList.add('hidden');
  document.getElementById('userEmail').classList.add('hidden');
  document.getElementById('signOutBtn').classList.add('hidden');
}

const PROVIDER_BADGE_INFO = {
  azure:  { label: 'Azure DevOps', color: '#0078D4' },
  jira:   { label: 'Jira',         color: '#0052CC' },
  github: { label: 'GitHub',       color: '#24292e' }
};

async function hideAuthGate() {
  document.getElementById('authSection').classList.add('hidden');
  const { activeProvider } = await chrome.storage.sync.get(['activeProvider']);
  updateProviderBadge(activeProvider);
  if (!activeProvider) {
    showIntegrationSetup();
  } else {
    showMainUI();
  }
}

function updateProviderBadge(provider) {
  const badge = document.getElementById('activeProviderBadge');
  if (provider && PROVIDER_BADGE_INFO[provider]) {
    const info = PROVIDER_BADGE_INFO[provider];
    badge.textContent = info.label;
    badge.style.background = info.color;
    badge.classList.remove('hidden');
  } else {
    badge.classList.add('hidden');
  }
}

function showIntegrationSetup() {
  document.getElementById('integrationSetupSection').classList.remove('hidden');
  document.getElementById('captureSection').classList.add('hidden');
  document.getElementById('manualFormSection').classList.add('hidden');
  document.getElementById('actionBar').classList.add('hidden');
}

function showMainUI() {
  document.getElementById('integrationSetupSection').classList.add('hidden');
  document.getElementById('captureSection').classList.remove('hidden');
  document.getElementById('manualFormSection').classList.remove('hidden');
  document.getElementById('actionBar').classList.remove('hidden');
  updateIntegrationButtons();
}

async function showUserEmail(token) {
  try {
    const res = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { 'Authorization': 'Bearer ' + token }
    });
    if (res.ok) {
      const info = await res.json();
      const emailEl = document.getElementById('userEmail');
      emailEl.textContent = info.email;
      emailEl.title = info.email;
      emailEl.classList.remove('hidden');
      document.getElementById('signOutBtn').classList.remove('hidden');
    }
  } catch (_) {}
}

async function authenticatedFetch(url, options = {}) {
  if (!currentToken) {
    currentToken = await getAuthToken(false);
  }

  options.headers = options.headers || {};
  options.headers['Authorization'] = 'Bearer ' + currentToken;

  let response = await fetch(url, options);

  // If 401, try re-auth once
  if (response.status === 401) {
    chrome.identity.removeCachedAuthToken({ token: currentToken }, () => {});
    currentToken = await getAuthToken(true);
    options.headers['Authorization'] = 'Bearer ' + currentToken;
    response = await fetch(url, options);
  }

  return response;
}

// ── Free tier report limit ──────────────────────────
const FREE_MONTHLY_LIMIT = 3;

async function getMonthlyUsage() {
  const data = await chrome.storage.local.get(['reportUsage']);
  const usage = data.reportUsage || { month: '', count: 0 };
  const currentMonth = new Date().toISOString().slice(0, 7); // "2026-02"
  if (usage.month !== currentMonth) {
    return { month: currentMonth, count: 0 };
  }
  return usage;
}

async function incrementUsage() {
  const usage = await getMonthlyUsage();
  usage.count += 1;
  await chrome.storage.local.set({ reportUsage: usage });
  updateUsageDisplay(usage);
  return usage;
}

function updateUsageDisplay(usage) {
  const el = document.getElementById('usageCounter');
  if (el) {
    const remaining = Math.max(0, FREE_MONTHLY_LIMIT - usage.count);
    el.textContent = `${remaining}/${FREE_MONTHLY_LIMIT} free`;
    if (remaining === 0) el.classList.add('limit-reached');
    else el.classList.remove('limit-reached');
  }
}

// ── Init ─────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', async () => {
  document.getElementById('settingsBtn').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });
  document.getElementById('analyzeBtn').addEventListener('click', analyzeWithAI);
  document.getElementById('copyBtn').addEventListener('click', copyReport);
  document.getElementById('sendAzureBtn').addEventListener('click', sendToAzureDevOps);
  document.getElementById('sendJiraBtn').addEventListener('click', sendToJira);
  document.getElementById('sendGithubBtn').addEventListener('click', sendToGithub);
  document.getElementById('annotateBtn').addEventListener('click', openAnnotation);

  // Auth buttons
  document.getElementById('signInBtn').addEventListener('click', async () => {
    const btn = document.getElementById('signInBtn');
    btn.disabled = true;
    btn.textContent = 'Signing in...';
    try {
      const token = await getAuthToken(true);
      hideAuthGate();
      showUserEmail(token);
      const usage = await getMonthlyUsage();
      updateUsageDisplay(usage);
      await capturePageData();
    } catch (err) {
      btn.disabled = false;
      btn.innerHTML = '<img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="G" class="google-icon"> Sign in with Google';
      showStatus('Sign in failed: ' + err.message, 'error');
    }
  });

  document.getElementById('signOutBtn').addEventListener('click', signOut);

  // Integration setup screen — set provider first, then open Settings
  document.getElementById('setupAzureBtn').addEventListener('click', async () => {
    await chrome.storage.sync.set({ activeProvider: 'azure' });
    chrome.runtime.openOptionsPage();
  });
  document.getElementById('setupJiraBtn').addEventListener('click', async () => {
    await chrome.storage.sync.set({ activeProvider: 'jira' });
    chrome.runtime.openOptionsPage();
  });
  document.getElementById('setupGithubBtn').addEventListener('click', async () => {
    await chrome.storage.sync.set({ activeProvider: 'github' });
    chrome.runtime.openOptionsPage();
  });
  document.getElementById('setupSkipBtn').addEventListener('click', showMainUI);

  // Try silent auth first
  try {
    const token = await getAuthToken(false);
    hideAuthGate();
    showUserEmail(token);
    const usage = await getMonthlyUsage();
    updateUsageDisplay(usage);

    // Check if the annotation editor saved a result while popup was closed
    const stored = await chrome.storage.local.get(['annotatedScreenshot', 'capturedDataCache']);
    if (stored.annotatedScreenshot) {
      // Restore annotated screenshot
      capturedData.screenshot = stored.annotatedScreenshot;
      document.getElementById('screenshotImg').src = stored.annotatedScreenshot;
      document.getElementById('screenshotPreview').classList.remove('hidden');
      document.getElementById('annotateBtn').classList.remove('hidden');
      document.querySelector('.screenshot-label').textContent = 'Screenshot annotated ✏️';
      await chrome.storage.local.remove(['annotatedScreenshot']);

      // Restore other captured data if available
      if (stored.capturedDataCache) {
        const cache = stored.capturedDataCache;
        capturedData.url         = cache.url         || capturedData.url;
        capturedData.browser     = cache.browser     || capturedData.browser;
        capturedData.os          = cache.os          || capturedData.os;
        capturedData.resolution  = cache.resolution  || capturedData.resolution;
        capturedData.viewport    = cache.viewport    || capturedData.viewport;
        capturedData.consoleLogs = cache.consoleLogs || capturedData.consoleLogs;
        capturedData.timestamp   = cache.timestamp   || capturedData.timestamp;
        await chrome.storage.local.remove(['capturedDataCache']);

        if (cache.url)         { const el = document.getElementById('urlValue');        el.textContent = truncate(cache.url, 45); el.title = cache.url; }
        if (cache.browser)       document.getElementById('browserValue').textContent    = cache.browser;
        if (cache.os)            document.getElementById('osValue').textContent         = cache.os;
        if (cache.resolution)    document.getElementById('resolutionValue').textContent = cache.resolution + (cache.viewport ? ' (viewport: ' + cache.viewport + ')' : '');
        const errCount  = (cache.consoleLogs || []).filter(e => ['error','uncaught','promise','network','csp'].includes(e.type)).length;
        const warnCount = (cache.consoleLogs || []).filter(e => e.type === 'warn').length;
        const logCount  = (cache.consoleLogs || []).length;
        const errEl     = document.getElementById('errorsValue');
        errEl.textContent = logCount > 0
          ? `${logCount} entries (${errCount} error${errCount !== 1 ? 's' : ''}, ${warnCount} warn${warnCount !== 1 ? 's' : ''})`
          : 'None';
      }
      // Show form after restoring annotated screenshot
      document.getElementById('manualFormSection').classList.remove('hidden');
      document.getElementById('actionBar').classList.remove('hidden');
      await updateIntegrationButtons();
    } else {
      await capturePageData();
    }
  } catch (_) {
    // No cached token — show auth gate
    showAuthGate();
  }
});

// ── Page Data Capture ─────────────────────────────────────────────────────────

async function capturePageData() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // Reject internal Chrome pages
    if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
      showStatus('BugSnap only works on regular web pages (http/https).', 'error');
      disableAnalyze();
      return;
    }

    capturedData.timestamp = new Date().toISOString();

    // Capture screenshot
    try {
      const screenshot = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
      capturedData.screenshot = screenshot;
      document.getElementById('screenshotImg').src = screenshot;
      document.getElementById('screenshotPreview').classList.remove('hidden');
      document.getElementById('annotateBtn').classList.remove('hidden');
    } catch (e) {
      console.warn('Screenshot capture failed:', e.message);
    }

    // Set URL
    capturedData.url = tab.url;
    const urlEl = document.getElementById('urlValue');
    urlEl.textContent = truncate(tab.url, 45);
    urlEl.title = tab.url;

    // Get browser/OS info and console errors from MAIN world
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'MAIN',
        func: () => {
          const ua = navigator.userAgent;

          // Detect browser
          let browser = 'Unknown';
          const chromeMatch  = ua.match(/Chrome\/([\d.]+)/);
          const firefoxMatch = ua.match(/Firefox\/([\d.]+)/);
          const safariMatch  = ua.match(/Version\/([\d.]+).*Safari/);
          const edgeMatch    = ua.match(/Edg\/([\d.]+)/);
          if (edgeMatch)    browser = 'Edge ' + edgeMatch[1];
          else if (chromeMatch)   browser = 'Chrome ' + chromeMatch[1];
          else if (firefoxMatch)  browser = 'Firefox ' + firefoxMatch[1];
          else if (safariMatch)   browser = 'Safari ' + safariMatch[1];

          // Detect OS
          let os = 'Unknown';
          if (ua.includes('Windows NT 10'))   os = 'Windows 10/11';
          else if (ua.includes('Windows'))    os = 'Windows';
          else if (ua.includes('Mac OS X'))   os = 'macOS';
          else if (ua.includes('Linux'))      os = 'Linux';
          else if (ua.includes('Android'))    os = 'Android';
          else if (ua.includes('iPhone') || ua.includes('iPad')) os = 'iOS';

          return {
            browser,
            os,
            resolution: screen.width + 'x' + screen.height,
            viewport: window.innerWidth + 'x' + window.innerHeight,
            logs: (() => {
              const all = window.__bugsnap_logs || [];
              // Always keep all errors/warnings; fill remaining slots with network_ok
              const priority = all.filter(e => e.type !== 'network_ok');
              const netOk    = all.filter(e => e.type === 'network_ok').slice(-50); // last 50 ok requests
              return [...priority, ...netOk].slice(0, 500);
            })()
          };
        }
      });

      if (results && results[0]?.result) {
        const info = results[0].result;
        capturedData.browser      = info.browser;
        capturedData.os           = info.os;
        capturedData.resolution   = info.resolution;
        capturedData.viewport     = info.viewport;
        capturedData.consoleLogs  = info.logs;

        document.getElementById('browserValue').textContent     = info.browser;
        document.getElementById('osValue').textContent          = info.os;
        document.getElementById('resolutionValue').textContent  = info.resolution + ' (viewport: ' + info.viewport + ')';

        const errCount  = info.logs.filter(e => ['error','uncaught','promise','network','csp'].includes(e.type)).length;
        const warnCount = info.logs.filter(e => e.type === 'warn').length;
        const logCount  = info.logs.length;
        const errEl     = document.getElementById('errorsValue');
        if (logCount > 0) {
          errEl.textContent = `${logCount} entries (${errCount} error${errCount !== 1 ? 's' : ''}, ${warnCount} warn${warnCount !== 1 ? 's' : ''})`;
          if (errCount > 0) errEl.classList.add('error-count');
        } else {
          errEl.textContent = 'None';
        }
      }
    } catch (e) {
      console.warn('Could not read page info:', e.message);
      document.getElementById('browserValue').textContent    = navigator.userAgent.includes('Chrome') ? 'Chrome' : 'Unknown';
      document.getElementById('osValue').textContent        = 'See report';
      document.getElementById('resolutionValue').textContent = screen.width + 'x' + screen.height;
      document.getElementById('errorsValue').textContent    = 'N/A';
    }

  } catch (err) {
    showStatus('Error capturing page data: ' + err.message, 'error');
    disableAnalyze();
  }
  // Show manual form and integration buttons after capture
  document.getElementById('manualFormSection').classList.remove('hidden');
  document.getElementById('actionBar').classList.remove('hidden');
  await updateIntegrationButtons();
}

// ── Claude AI Analysis ────────────────────────────────────────────────────────

async function analyzeWithAI() {
  const description = document.getElementById('descriptionInput').value.trim();

  // Check free tier limit
  const usage = await getMonthlyUsage();
  if (usage.count >= FREE_MONTHLY_LIMIT) {
    showStatus(`🔒 Monthly limit reached (${FREE_MONTHLY_LIMIT} free reports). Upgrade to Pro for unlimited AI reports.`, 'error');
    return;
  }

  // Switch to loading state
  document.getElementById('manualFormSection').classList.add('hidden');
  document.getElementById('actionBar').classList.add('hidden');
  document.getElementById('loadingSection').classList.remove('hidden');
  document.getElementById('reportSection').classList.add('hidden');
  document.getElementById('statusMsg').classList.add('hidden');

  try {
    const errors = capturedData.consoleLogs.filter(e => ['error','uncaught','promise','network','csp'].includes(e.type));
    const errorsText = errors.length > 0
      ? errors.map(e => `[${e.type.toUpperCase()}] ${e.message} (${e.time})`).join('\n')
      : 'No console errors captured.';

    const prompt = `You are a professional QA engineer. Analyze this bug screenshot and the technical data below to generate a complete, structured bug report.

**Technical Data:**
- URL: ${capturedData.url}
- Browser: ${capturedData.browser || 'Unknown'}
- OS: ${capturedData.os || 'Unknown'}
- Screen Resolution: ${capturedData.resolution || 'Unknown'}
- Viewport: ${capturedData.viewport || 'Unknown'}
- Timestamp: ${capturedData.timestamp}
- Console Errors:
${errorsText}
- User Description: ${description || '(No description provided)'}

Generate a professional bug report in this EXACT Markdown format:

## Bug Title
[Concise title — max 10 words]

## Summary
[1-2 sentences describing what the bug is]

## Environment
- **URL:** [from data]
- **Browser:** [from data]
- **OS:** [from data]
- **Resolution:** [from data]

## Steps to Reproduce
1. [First step — infer from the screenshot and description]
2. [Continue as needed]

## Expected Behavior
[What should happen]

## Actual Behavior
[What actually happens — based on screenshot]

## Severity
**[Critical / High / Medium / Low]** — [brief justification in one sentence]

## Console Errors
${errors.length > 0 ? '[List the errors from the data]' : 'No console errors captured.'}

## Additional Notes
[Any other relevant observations from the screenshot]

Be specific and professional. Base your analysis on what you see in the screenshot.`;

    const requestBody = {
      model: CLAUDE_MODEL,
      max_tokens: 2000,
      messages: [
        {
          role: 'user',
          content: capturedData.screenshot
            ? [
                {
                  type: 'image',
                  source: {
                    type: 'base64',
                    media_type: 'image/png',
                    data: capturedData.screenshot.replace(/^data:image\/png;base64,/, '')
                  }
                },
                { type: 'text', text: prompt }
              ]
            : [{ type: 'text', text: prompt }]
        }
      ]
    };

    const response = await authenticatedFetch(PROXY_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      let errorMsg = `API Error ${response.status}`;
      try {
        const errData = await response.json();
        errorMsg = errData.error?.message || errorMsg;
      } catch (_) {}
      throw new Error(errorMsg);
    }

    const data = await response.json();
    const reportText = data.content?.[0]?.text;

    if (!reportText) {
      throw new Error('Empty response from Claude API');
    }

    // Append BugSnap branding footer
    const reportWithFooter = reportText.trimEnd() + '\n\n---\n*Captured with [BugSnap](https://anivlisluz.github.io/bugsnap-landing/) — AI-powered bug reporting*';

    generatedReport = {
      markdown: reportWithFooter,
      title: extractTitle(reportWithFooter),
      severity: extractSeverity(reportWithFooter)
    };

    // Increment usage counter
    await incrementUsage();

    // Auto-fill the manual form fields with AI results
    document.getElementById('bugTitle').value = generatedReport.title;
    document.getElementById('bugSeverity').value = generatedReport.severity || 'Medium';

    // Show AI report preview + restore form + action bar
    document.getElementById('loadingSection').classList.add('hidden');
    document.getElementById('manualFormSection').classList.remove('hidden');
    document.getElementById('reportSection').classList.remove('hidden');
    document.getElementById('reportContent').innerHTML = markdownToHtml(reportText);
    document.getElementById('actionBar').classList.remove('hidden');

    // Show/hide integration buttons based on config
    await updateIntegrationButtons();

  } catch (err) {
    document.getElementById('loadingSection').classList.add('hidden');
    document.getElementById('manualFormSection').classList.remove('hidden');
    document.getElementById('actionBar').classList.remove('hidden');
    showStatus('Error: ' + err.message, 'error');
  }
}

// ── Manual report helpers ─────────────────────────────────────────────────────

function getReportData() {
  if (generatedReport) return generatedReport;
  const title    = document.getElementById('bugTitle').value.trim();
  const severity = document.getElementById('bugSeverity').value || 'Medium';
  const desc     = document.getElementById('descriptionInput')?.value.trim() || '';
  return { title, severity, markdown: buildManualMarkdown(title, desc, severity) };
}

function buildManualMarkdown(title, desc, severity) {
  const lines = [];
  lines.push(`## ${title || 'Bug Report'}`);
  lines.push('');
  if (desc) {
    lines.push('## Description');
    lines.push(desc);
    lines.push('');
  }
  lines.push('## Environment');
  if (capturedData.url)        lines.push(`- **URL:** ${capturedData.url}`);
  if (capturedData.browser)    lines.push(`- **Browser:** ${capturedData.browser}`);
  if (capturedData.os)         lines.push(`- **OS:** ${capturedData.os}`);
  if (capturedData.resolution) lines.push(`- **Resolution:** ${capturedData.resolution}`);
  if (capturedData.timestamp)  lines.push(`- **Timestamp:** ${capturedData.timestamp}`);
  lines.push('');
  lines.push('## Severity');
  lines.push(`**${severity}**`);
  const errors = (capturedData.consoleLogs || []).filter(e => ['error','uncaught','promise','network','csp'].includes(e.type));
  if (errors.length > 0) {
    lines.push('');
    lines.push('## Console Errors');
    errors.slice(0, 10).forEach(e => lines.push(`- [${e.type.toUpperCase()}] ${e.message}`));
  }
  lines.push('');
  lines.push('---');
  lines.push('*Captured with [BugSnap](https://anivlisluz.github.io/bugsnap-landing/)*');
  return lines.join('\n');
}

// ── Copy to Clipboard ────────────────────────────────────────────────────────

async function copyReport() {
  const reportData = getReportData();
  if (!reportData.title) { showStatus('Please enter a bug title first.', 'error'); return; }
  try {
    await navigator.clipboard.writeText(reportData.markdown);
    const btn = document.getElementById('copyBtn');
    btn.textContent = '✅ Copied!';
    setTimeout(() => { btn.textContent = '📋 Copy'; }, 2500);
  } catch (_) {
    showStatus('Could not copy. Select and copy the text manually.', 'error');
  }
}

// ── Azure DevOps Integration ─────────────────────────────────────────────────

const ENTRA_CLIENT_ID_POPUP    = '726efb90-7519-49bc-81d6-fb3ca827fd1a';
const ENTRA_TOKEN_URL_POPUP    = 'https://login.microsoftonline.com/common/oauth2/v2.0/token';
const AZURE_DEVOPS_SCOPE_POPUP = '499b84ac-1321-427f-aa17-267ca6975798/user_impersonation offline_access';

async function getAzureTokenForPopup() {
  const saved = await chrome.storage.sync.get(['azureOAuthToken', 'azureOAuthRefreshToken', 'azureOAuthExpiry']);
  if (!saved.azureOAuthToken) return null;

  if (saved.azureOAuthExpiry && Date.now() < saved.azureOAuthExpiry) {
    return saved.azureOAuthToken;
  }

  if (!saved.azureOAuthRefreshToken) return null;
  try {
    const tokenForm = new URLSearchParams({
      client_id:     ENTRA_CLIENT_ID_POPUP,
      grant_type:    'refresh_token',
      refresh_token: saved.azureOAuthRefreshToken,
      scope:         AZURE_DEVOPS_SCOPE_POPUP
    });

    const res = await fetch(ENTRA_TOKEN_URL_POPUP, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: tokenForm.toString()
    });
    const data = await res.json();
    if (!res.ok || data.error) return null;

    const expiry = Date.now() + (data.expires_in - 60) * 1000;
    await chrome.storage.sync.set({
      azureOAuthToken:        data.access_token,
      azureOAuthRefreshToken: data.refresh_token,
      azureOAuthExpiry:       expiry
    });
    return data.access_token;
  } catch (_) {
    return null;
  }
}

async function sendToAzureDevOps() {
  const reportData = getReportData();
  if (!reportData.title) { showStatus('Please enter a bug title first.', 'error'); return; }

  const settings = await chrome.storage.sync.get([
    'azureOrg', 'azureProject', 'azurePat', 'azureWorkItemType', 'azureAreaPath', 'azureAssignedTo',
    'azureManualMode', 'azureOAuthOrg', 'azureOAuthProject',
    'azureOAuthToken', 'azureOAuthRefreshToken', 'azureOAuthExpiry'
  ]);

  // Resolve credentials based on mode
  let orgUrl, projectName, project, authHeader;
  if (settings.azureManualMode) {
    if (!settings.azureOrg || !settings.azureProject || !settings.azurePat) {
      showStatus('⚙️ Azure DevOps not configured. Open Settings and fill in Org, Project, and PAT.', 'error');
      return;
    }
    orgUrl      = settings.azureOrg.replace(/\/$/, '');
    projectName = settings.azureProject;
    project     = encodeURIComponent(settings.azureProject);
    authHeader  = 'Basic ' + btoa(':' + settings.azurePat);
  } else {
    const oauthToken = await getAzureTokenForPopup();
    if (!oauthToken || !settings.azureOAuthOrg || !settings.azureOAuthProject) {
      showStatus('⚙️ Azure DevOps not connected. Open Settings and sign in with Azure DevOps.', 'error');
      return;
    }
    // Strip protocol prefix if user accidentally saved full URL as org name
    const oauthOrgName = settings.azureOAuthOrg.replace(/^https?:\/\/[^/]+\//, '').replace(/\/$/, '');
    orgUrl      = `https://dev.azure.com/${oauthOrgName}`;
    projectName = settings.azureOAuthProject;
    project     = encodeURIComponent(settings.azureOAuthProject);
    authHeader  = 'Bearer ' + oauthToken;
  }

  const btn = document.getElementById('sendAzureBtn');
  btn.textContent = '⏳ Sending...';
  btn.disabled = true;

  try {
    const workItemType = settings.azureWorkItemType || 'Bug';
    const url          = `${orgUrl}/${project}/_apis/wit/workitems/$${encodeURIComponent(workItemType)}?api-version=7.0`;

    // Convert Markdown to rich HTML for Azure DevOps description fields
    const descriptionHtml = markdownToAzureHtml(reportData.markdown);

    const severityMap = {
      'Critical': '1 - Critical',
      'High':     '2 - High',
      'Medium':   '3 - Medium',
      'Low':      '4 - Low'
    };

    const patchBody = [
      { op: 'add', path: '/fields/System.Title',                       value: reportData.title },
      { op: 'add', path: '/fields/System.Description',                 value: descriptionHtml },
      { op: 'add', path: '/fields/Microsoft.VSTS.TCM.ReproSteps',      value: descriptionHtml },
      { op: 'add', path: '/fields/Microsoft.VSTS.Common.Severity',     value: severityMap[reportData.severity] || '3 - Medium' }
    ];

    if (settings.azureAreaPath)   patchBody.push({ op: 'add', path: '/fields/System.AreaPath',   value: settings.azureAreaPath });
    if (settings.azureAssignedTo) patchBody.push({ op: 'add', path: '/fields/System.AssignedTo', value: settings.azureAssignedTo });

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type':  'application/json-patch+json',
        'Authorization': authHeader
      },
      body: JSON.stringify(patchBody)
    });

    if (!response.ok) {
      let errorMsg = `Azure DevOps Error ${response.status}`;
      try {
        const errData = await response.json();
        errorMsg = errData.message || errorMsg;
      } catch (_) {}
      throw new Error(errorMsg);
    }

    let result;
    try {
      result = await response.json();
    } catch (_) {
      throw new Error('Your account does not have API access to this Azure DevOps organization. Open Settings and use a Personal Access Token (PAT) from that organization instead.');
    }
    const workItemId  = result.id;
    const workItemUrl = result._links?.html?.href
      || `${orgUrl}/${projectName}/_workitems/edit/${workItemId}`;

    // Attach screenshot if available
    if (capturedData.screenshot) {
      try {
        btn.textContent = '📎 Attaching screenshot...';

        // 1. Convert base64 to binary
        const base64Data = capturedData.screenshot.replace(/^data:image\/png;base64,/, '');
        const binaryStr  = atob(base64Data);
        const bytes      = new Uint8Array(binaryStr.length);
        for (let i = 0; i < binaryStr.length; i++) bytes[i] = binaryStr.charCodeAt(i);

        // 2. Upload the image to Azure DevOps attachments API
        const uploadUrl = `${orgUrl}/${project}/_apis/wit/attachments?fileName=bugsnap-screenshot.png&api-version=7.0`;
        const uploadRes = await fetch(uploadUrl, {
          method: 'POST',
          headers: {
            'Content-Type':  'application/octet-stream',
            'Authorization': authHeader
          },
          body: bytes
        });

        if (uploadRes.ok) {
          const uploadData = await uploadRes.json();

          // 3. Link the attachment to the work item
          const patchAttachUrl = `${orgUrl}/${project}/_apis/wit/workitems/${workItemId}?api-version=7.0`;
          await fetch(patchAttachUrl, {
            method: 'PATCH',
            headers: {
              'Content-Type':  'application/json-patch+json',
              'Authorization': authHeader
            },
            body: JSON.stringify([{
              op: 'add',
              path: '/relations/-',
              value: {
                rel: 'AttachedFile',
                url: uploadData.url,
                attributes: { comment: 'BugSnap screenshot' }
              }
            }])
          });
        }
      } catch (attachErr) {
        console.warn('Screenshot attachment failed (work item was still created):', attachErr.message);
      }
    }

    // Always attach console log file (even if empty)
    let logAttached = false;
    try {
      btn.textContent = '📎 Attaching console log...';

      const { verboseNetwork } = await chrome.storage.sync.get(['verboseNetwork']);

      const logLines = capturedData.consoleLogs.length > 0
        ? capturedData.consoleLogs.map(e => {
            const t    = new Date(e.time).toLocaleTimeString();
            const label = e.type === 'network_ok' ? 'NET OK ' : e.type.toUpperCase().padEnd(7);
            let line = `[${t}] [${label}] ${e.message}`;
            if (verboseNetwork && e.body) {
              line += `\n          Response: ${e.body}`;
            }
            return line;
          })
        : ['(No console activity captured — reload the page with the extension active to capture logs)'];

      const logText = [
        `BugSnap Console Log`,
        `URL: ${capturedData.url}`,
        `Captured: ${capturedData.timestamp}`,
        `Total entries: ${capturedData.consoleLogs.length}`,
        '─'.repeat(60),
        ...logLines
      ].join('\n');

      const logBytes = new TextEncoder().encode(logText);
      const logUploadUrl = `${orgUrl}/${project}/_apis/wit/attachments?fileName=bugsnap-console-log.txt&api-version=7.0`;
      const logUploadRes = await fetch(logUploadUrl, {
        method: 'POST',
        headers: {
          'Content-Type':  'application/octet-stream',
          'Authorization': authHeader
        },
        body: logBytes
      });

      if (!logUploadRes.ok) {
        const errData = await logUploadRes.json().catch(() => ({}));
        throw new Error(errData.message || `HTTP ${logUploadRes.status}`);
      }

      const logUploadData = await logUploadRes.json();
      const patchLogUrl = `${orgUrl}/${project}/_apis/wit/workitems/${workItemId}?api-version=7.0`;
      const patchRes = await fetch(patchLogUrl, {
        method: 'PATCH',
        headers: {
          'Content-Type':  'application/json-patch+json',
          'Authorization': authHeader
        },
        body: JSON.stringify([{
          op: 'add',
          path: '/relations/-',
          value: {
            rel: 'AttachedFile',
            url: logUploadData.url,
            attributes: { comment: `BugSnap console log (${capturedData.consoleLogs.length} entries)` }
          }
        }])
      });

      if (patchRes.ok) logAttached = true;
    } catch (logErr) {
      console.warn('Console log attachment failed:', logErr.message);
    }

    btn.textContent = '✅ Sent!';
    const attachNote = logAttached
      ? ` + log attached (${capturedData.consoleLogs.length} entries)`
      : ' (log attach failed — check console)';
    showStatus(
      `Work Item #${workItemId} created${attachNote}! <a href="${workItemUrl}" target="_blank">Open in Azure DevOps →</a>`,
      'success'
    );

  } catch (err) {
    btn.textContent = '🚀 Send to Azure DevOps';
    btn.disabled = false;
    showStatus('Error: ' + err.message, 'error');
  }
}

// ── Annotation ───────────────────────────────────────────────────────────────

async function openAnnotation() {
  if (!capturedData.screenshot) return;

  // Save screenshot + captured data to local storage so the annotation tab can access it
  await chrome.storage.local.set({
    pendingAnnotationScreenshot: capturedData.screenshot,
    capturedDataCache: {
      url:         capturedData.url,
      browser:     capturedData.browser,
      os:          capturedData.os,
      resolution:  capturedData.resolution,
      viewport:    capturedData.viewport,
      consoleLogs: capturedData.consoleLogs,
      timestamp:   capturedData.timestamp
    }
  });

  // Open annotation editor as a floating popup window
  chrome.windows.create({
    url:    chrome.runtime.getURL('annotation.html'),
    type:   'popup',
    width:  Math.min(window.screen.availWidth,  1600),
    height: Math.min(window.screen.availHeight, 1000),
    left:   0,
    top:    0,
    focused: true
  });
  // Popup closes when the new window opens — that's expected.
  // When user returns to the extension, the result is restored from storage.
}

// ── Integration Button Visibility ─────────────────────────────────────────────

async function updateIntegrationButtons() {
  const settings = await chrome.storage.sync.get([
    'activeProvider',
    'azureOrg', 'azureProject', 'azurePat',
    'azureManualMode', 'azureOAuthToken', 'azureOAuthOrg', 'azureOAuthProject',
    'jiraDomain', 'jiraEmail', 'jiraToken', 'jiraProjectKey',
    'jiraManualMode', 'jiraOAuthToken', 'jiraOAuthCloudId', 'jiraOAuthProject',
    'githubRepo', 'githubToken',
    'githubOAuthToken', 'githubRepoFullName', 'githubManualMode'
  ]);

  const azureBtn  = document.getElementById('sendAzureBtn');
  const jiraBtn   = document.getElementById('sendJiraBtn');
  const githubBtn = document.getElementById('sendGithubBtn');

  azureBtn.classList.add('hidden');
  jiraBtn.classList.add('hidden');
  githubBtn.classList.add('hidden');

  const provider = settings.activeProvider;

  if (provider === 'azure') {
    // For OAuth: token presence = user is authenticated → show button.
    // Org/project are validated at send time. Fallback to org+project if token temporarily absent.
    const ok = settings.azureManualMode
      ? !!(settings.azureOrg && settings.azureProject && settings.azurePat)
      : !!(settings.azureOAuthToken || (settings.azureOAuthOrg && settings.azureOAuthProject));
    if (ok) { azureBtn.classList.remove('hidden'); azureBtn.textContent = '🚀 Azure DevOps'; }
    else showSetupButton(azureBtn);

  } else if (provider === 'jira') {
    const oauthOk  = !!(settings.jiraOAuthToken && settings.jiraOAuthCloudId && settings.jiraOAuthProject);
    const manualOk = !!(settings.jiraDomain && settings.jiraEmail && settings.jiraToken && settings.jiraProjectKey);
    if (oauthOk || manualOk) { jiraBtn.classList.remove('hidden'); jiraBtn.textContent = '🔷 Jira'; }
    else showSetupButton(jiraBtn);

  } else if (provider === 'github') {
    const repo  = settings.githubManualMode ? settings.githubRepo : (settings.githubRepoFullName || settings.githubRepo);
    const token = settings.githubManualMode ? settings.githubToken : (settings.githubOAuthToken || settings.githubToken);
    if (repo && token) { githubBtn.classList.remove('hidden'); githubBtn.textContent = '🐙 GitHub'; }
    else showSetupButton(azureBtn);

  } else {
    showSetupButton(azureBtn);
  }
}

function showSetupButton(btn) {
  btn.classList.remove('hidden');
  btn.textContent = '⚙️ Configure integration';
  btn.onclick = () => chrome.runtime.openOptionsPage();
}

// ── Jira OAuth token helper (popup) ──────────────────────────────────────────

async function getJiraToken() {
  const WORKER = 'https://bugsnap-proxy.luzchoquej.workers.dev';
  const saved = await chrome.storage.sync.get(['jiraOAuthToken', 'jiraOAuthRefreshToken', 'jiraOAuthExpiry']);
  if (!saved.jiraOAuthToken) return null;

  if (saved.jiraOAuthExpiry && Date.now() < saved.jiraOAuthExpiry) {
    return saved.jiraOAuthToken;
  }

  if (!saved.jiraOAuthRefreshToken) return null;

  try {
    const res = await fetch(`${WORKER}/jira/oauth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: saved.jiraOAuthRefreshToken })
    });
    const data = await res.json();
    if (!res.ok || data.error) return null;

    const expiry = Date.now() + (data.expires_in - 60) * 1000;
    await chrome.storage.sync.set({
      jiraOAuthToken:        data.access_token,
      jiraOAuthRefreshToken: data.refresh_token,
      jiraOAuthExpiry:       expiry
    });
    return data.access_token;
  } catch (_) {
    return null;
  }
}

// ── Jira Integration ─────────────────────────────────────────────────────────

async function sendToJira() {
  const reportData = getReportData();
  if (!reportData.title) { showStatus('Please enter a bug title first.', 'error'); return; }

  const settings = await chrome.storage.sync.get([
    'jiraManualMode',
    'jiraDomain', 'jiraEmail', 'jiraToken', 'jiraProjectKey', 'jiraIssueType', 'jiraAssignee',
    'jiraOAuthToken', 'jiraOAuthCloudId', 'jiraOAuthProject', 'jiraOAuthIssueType', 'jiraOAuthAssignee'
  ]);

  const btn = document.getElementById('sendJiraBtn');
  btn.textContent = '⏳ Sending...';
  btn.disabled = true;

  // Resolve auth mode: OAuth preferred unless manual mode enabled
  let baseUrl, authHeader, projectKey, issueType, assigneeId;

  if (!settings.jiraManualMode && settings.jiraOAuthToken && settings.jiraOAuthCloudId && settings.jiraOAuthProject) {
    // OAuth mode
    const token = await getJiraToken();
    if (!token) {
      showStatus('⚙️ Jira session expired. Open Settings and reconnect.', 'error');
      btn.textContent = '🔷 Jira';
      btn.disabled = false;
      return;
    }
    baseUrl    = `https://api.atlassian.com/ex/jira/${settings.jiraOAuthCloudId}`;
    authHeader = `Bearer ${token}`;
    projectKey = settings.jiraOAuthProject;
    issueType  = settings.jiraOAuthIssueType || 'Bug';
    assigneeId = settings.jiraOAuthAssignee || null;

  } else if (settings.jiraDomain && settings.jiraEmail && settings.jiraToken && settings.jiraProjectKey) {
    // Manual PAT mode
    const domain = settings.jiraDomain.replace(/\/$/, '').replace(/^https?:\/\//, '');
    baseUrl    = `https://${domain}`;
    authHeader = 'Basic ' + btoa(settings.jiraEmail + ':' + settings.jiraToken);
    projectKey = settings.jiraProjectKey;
    issueType  = settings.jiraIssueType || 'Bug';
    assigneeId = settings.jiraAssignee || null;

  } else {
    showStatus('⚙️ Jira not configured. Open Settings to connect.', 'error');
    btn.textContent = '🔷 Jira';
    btn.disabled = false;
    return;
  }

  try {
    const auth      = authHeader;
    // issueType already resolved above

    const priorityMap = {
      'Critical': 'Highest',
      'High':     'High',
      'Medium':   'Medium',
      'Low':      'Low'
    };

    const adfDescription = markdownToAdf(reportData.markdown);

    const issueBody = {
      fields: {
        project:     { key: projectKey },
        summary:     reportData.title,
        description: adfDescription,
        issuetype:   { name: issueType },
        priority:    { name: priorityMap[reportData.severity] || 'Medium' },
        labels:      ['BugSnap']
      }
    };

    if (assigneeId) {
      issueBody.fields.assignee = { accountId: assigneeId };
    }

    const response = await fetch(`${baseUrl}/rest/api/3/issue`, {
      method: 'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': auth
      },
      body: JSON.stringify(issueBody)
    });

    if (!response.ok) {
      let errorMsg = `Jira Error ${response.status}`;
      try {
        const errData = await response.json();
        errorMsg = errData.errorMessages?.join(', ')
                || Object.values(errData.errors || {}).join(', ')
                || errorMsg;
      } catch (_) {}
      throw new Error(errorMsg);
    }

    const result   = await response.json();
    const issueKey = result.key;
    // For OAuth mode baseUrl is api.atlassian.com — derive browse URL from saved site info
    const saved2 = await chrome.storage.sync.get(['jiraOAuthSiteUrl', 'jiraDomain', 'jiraManualMode']);
    const browseBase = (!saved2.jiraManualMode && saved2.jiraOAuthSiteUrl)
      ? saved2.jiraOAuthSiteUrl
      : baseUrl;
    const issueUrl = `${browseBase}/browse/${issueKey}`;

    // Attach screenshot
    if (capturedData.screenshot) {
      try {
        btn.textContent = '📎 Attaching screenshot...';
        const base64Data = capturedData.screenshot.replace(/^data:image\/png;base64,/, '');
        const binaryStr  = atob(base64Data);
        const bytes      = new Uint8Array(binaryStr.length);
        for (let i = 0; i < binaryStr.length; i++) bytes[i] = binaryStr.charCodeAt(i);

        const blob     = new Blob([bytes], { type: 'image/png' });
        const formData = new FormData();
        formData.append('file', blob, 'bugsnap-screenshot.png');

        await fetch(`${baseUrl}/rest/api/3/issue/${issueKey}/attachments`, {
          method: 'POST',
          headers: {
            'Authorization':     auth,
            'X-Atlassian-Token': 'no-check'
          },
          body: formData
        });
      } catch (attachErr) {
        console.warn('Screenshot attachment failed (issue was still created):', attachErr.message);
      }
    }

    // Attach console log
    let logAttached = false;
    try {
      btn.textContent = '📎 Attaching console log...';
      const { verboseNetwork } = await chrome.storage.sync.get(['verboseNetwork']);

      const logLines = capturedData.consoleLogs.length > 0
        ? capturedData.consoleLogs.map(e => {
            const t     = new Date(e.time).toLocaleTimeString();
            const label = e.type === 'network_ok' ? 'NET OK ' : e.type.toUpperCase().padEnd(7);
            let line    = `[${t}] [${label}] ${e.message}`;
            if (verboseNetwork && e.body) line += `\n          Response: ${e.body}`;
            return line;
          })
        : ['(No console activity captured)'];

      const logText = [
        'BugSnap Console Log',
        `URL: ${capturedData.url}`,
        `Captured: ${capturedData.timestamp}`,
        `Total entries: ${capturedData.consoleLogs.length}`,
        '\u2500'.repeat(60),
        ...logLines
      ].join('\n');

      const logBlob  = new Blob([logText], { type: 'text/plain' });
      const formData = new FormData();
      formData.append('file', logBlob, 'bugsnap-console-log.txt');

      const attachRes = await fetch(`${baseUrl}/rest/api/3/issue/${issueKey}/attachments`, {
        method: 'POST',
        headers: {
          'Authorization':     auth,
          'X-Atlassian-Token': 'no-check'
        },
        body: formData
      });

      if (attachRes.ok) logAttached = true;
    } catch (logErr) {
      console.warn('Console log attachment failed:', logErr.message);
    }

    btn.textContent = '✅ Sent!';
    const attachNote = logAttached
      ? ` + log attached (${capturedData.consoleLogs.length} entries)`
      : ' (log attach failed)';
    showStatus(
      `${issueKey} created${attachNote}! <a href="${issueUrl}" target="_blank">Open in Jira →</a>`,
      'success'
    );

  } catch (err) {
    btn.textContent = '🔷 Jira';
    btn.disabled = false;
    showStatus('Error: ' + err.message, 'error');
  }
}

// ── GitHub Issues Integration ─────────────────────────────────────────────────

async function sendToGithub() {
  const reportData = getReportData();
  if (!reportData.title) { showStatus('Please enter a bug title first.', 'error'); return; }

  const settings = await chrome.storage.sync.get([
    'githubRepo', 'githubToken', 'githubLabels', 'githubAssignee',
    'githubOAuthToken', 'githubRepoFullName', 'githubManualMode', 'githubOAuthUser'
  ]);

  // Resolve which token and repo to use: OAuth preferred, PAT as fallback
  let repo, token;
  if (settings.githubManualMode) {
    repo  = settings.githubRepo;
    token = settings.githubToken;
  } else {
    repo  = settings.githubRepoFullName || settings.githubRepo;
    token = settings.githubOAuthToken || settings.githubToken;
  }

  if (!repo || !token) {
    showStatus('⚙️ GitHub not configured. Open Settings and connect GitHub or enter a PAT.', 'error');
    return;
  }

  const btn = document.getElementById('sendGithubBtn');
  btn.textContent = '⏳ Sending...';
  btn.disabled = true;

  try {
    repo  = repo.trim();
    token = token.trim();

    // Build issue body: report markdown + console log summary
    let body = reportData.markdown;

    // Append console log as collapsible details block
    if (capturedData.consoleLogs.length > 0) {
      const { verboseNetwork } = await chrome.storage.sync.get(['verboseNetwork']);
      const logLines = capturedData.consoleLogs.map(e => {
        const t     = new Date(e.time).toLocaleTimeString();
        const label = e.type === 'network_ok' ? 'NET OK ' : e.type.toUpperCase().padEnd(7);
        let line    = `[${t}] [${label}] ${e.message}`;
        if (verboseNetwork && e.body) line += `\n          Response: ${e.body}`;
        return line;
      });

      body += '\n\n<details>\n<summary>Console Log (' + capturedData.consoleLogs.length + ' entries)</summary>\n\n```\n' + logLines.join('\n') + '\n```\n\n</details>';
    }

    // Build labels array
    const labels = ['BugSnap'];
    if (settings.githubLabels) {
      settings.githubLabels.split(',').forEach(l => {
        const trimmed = l.trim();
        if (trimmed && !labels.includes(trimmed)) labels.push(trimmed);
      });
    }

    const issueBody = {
      title: reportData.title,
      body,
      labels
    };

    if (settings.githubAssignee) {
      let assignee = settings.githubAssignee.trim();
      // @me is not valid for GitHub Issues API — replace with actual authenticated username
      if (assignee === '@me' && settings.githubOAuthUser) {
        // githubOAuthUser is stored as an object {login, avatar_url} — extract the login string
        assignee = settings.githubOAuthUser.login || settings.githubOAuthUser;
      }
      if (assignee && assignee !== '@me') {
        issueBody.assignees = [assignee];
      }
    }

    const response = await fetch(`https://api.github.com/repos/${repo}/issues`, {
      method: 'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + token,
        'Accept':        'application/vnd.github+json'
      },
      body: JSON.stringify(issueBody)
    });

    if (!response.ok) {
      let errorMsg = `GitHub Error ${response.status}`;
      try {
        const errData = await response.json();
        errorMsg = errData.message || errorMsg;
      } catch (_) {}
      throw new Error(errorMsg);
    }

    const result   = await response.json();
    const issueNum = result.number;
    const issueUrl = result.html_url;

    // Upload screenshot to repo and add as comment
    if (capturedData.screenshot) {
      try {
        btn.textContent = '📎 Attaching screenshot...';
        const base64Data = capturedData.screenshot.replace(/^data:image\/png;base64,/, '');
        const timestamp  = new Date().toISOString().replace(/[:.]/g, '-');
        const filePath   = `.bugsnap/screenshot-${timestamp}.png`;

        // Upload image to repo via Contents API
        const uploadRes = await fetch(`https://api.github.com/repos/${repo}/contents/${filePath}`, {
          method: 'PUT',
          headers: {
            'Content-Type':  'application/json',
            'Authorization': 'Bearer ' + token,
            'Accept':        'application/vnd.github+json'
          },
          body: JSON.stringify({
            message: `BugSnap screenshot for issue #${issueNum}`,
            content: base64Data
          })
        });

        if (uploadRes.ok) {
          const uploadData = await uploadRes.json();
          const imageUrl   = uploadData.content.download_url;

          // Add comment with embedded screenshot
          await fetch(`https://api.github.com/repos/${repo}/issues/${issueNum}/comments`, {
            method: 'POST',
            headers: {
              'Content-Type':  'application/json',
              'Authorization': 'Bearer ' + token,
              'Accept':        'application/vnd.github+json'
            },
            body: JSON.stringify({
              body: `### Screenshot\n\n![BugSnap Screenshot](${imageUrl})`
            })
          });
        }
      } catch (attachErr) {
        console.warn('Screenshot upload failed (issue was still created):', attachErr.message);
      }
    }

    btn.textContent = '✅ Sent!';
    showStatus(
      `Issue #${issueNum} created! <a href="${issueUrl}" target="_blank">Open in GitHub →</a>`,
      'success'
    );

  } catch (err) {
    btn.textContent = '🐙 GitHub';
    btn.disabled = false;
    showStatus('Error: ' + err.message, 'error');
  }
}

// ── Markdown to ADF (Atlassian Document Format) ──────────────────────────────

function markdownToAdf(md) {
  const lines   = md.split('\n');
  const content = [];

  let inOl = false, olItems = [];
  let inUl = false, ulItems = [];

  const flushOl = () => {
    if (inOl && olItems.length) {
      content.push({
        type: 'orderedList',
        content: olItems.map(text => ({
          type: 'listItem',
          content: [{ type: 'paragraph', content: parseInline(text) }]
        }))
      });
      olItems = []; inOl = false;
    }
  };

  const flushUl = () => {
    if (inUl && ulItems.length) {
      content.push({
        type: 'bulletList',
        content: ulItems.map(text => ({
          type: 'listItem',
          content: [{ type: 'paragraph', content: parseInline(text) }]
        }))
      });
      ulItems = []; inUl = false;
    }
  };

  const flushLists = () => { flushOl(); flushUl(); };

  function parseInline(text) {
    const nodes = [];
    const re = /(\*\*(.+?)\*\*|\*(.+?)\*|`(.+?)`|\[([^\]]+)\]\(([^)]+)\))/g;
    let lastIndex = 0;
    let match;

    while ((match = re.exec(text)) !== null) {
      if (match.index > lastIndex) {
        nodes.push({ type: 'text', text: text.slice(lastIndex, match.index) });
      }
      if (match[2])              nodes.push({ type: 'text', text: match[2], marks: [{ type: 'strong' }] });
      else if (match[3])         nodes.push({ type: 'text', text: match[3], marks: [{ type: 'em' }] });
      else if (match[4])         nodes.push({ type: 'text', text: match[4], marks: [{ type: 'code' }] });
      else if (match[5])         nodes.push({ type: 'text', text: match[5], marks: [{ type: 'link', attrs: { href: match[6] } }] });
      lastIndex = re.lastIndex;
    }

    if (lastIndex < text.length) {
      nodes.push({ type: 'text', text: text.slice(lastIndex) });
    }

    return nodes.length > 0 ? nodes : [{ type: 'text', text: text || ' ' }];
  }

  for (const raw of lines) {
    const line = raw.trimEnd();

    if (/^---+$/.test(line.trim())) { flushLists(); content.push({ type: 'rule' }); continue; }

    if (/^## (.+)/.test(line)) {
      flushLists();
      content.push({ type: 'heading', attrs: { level: 2 }, content: parseInline(line.replace(/^## /, '')) });
      continue;
    }

    if (/^### (.+)/.test(line)) {
      flushLists();
      content.push({ type: 'heading', attrs: { level: 3 }, content: parseInline(line.replace(/^### /, '')) });
      continue;
    }

    if (/^\d+\. (.+)/.test(line)) { flushUl(); inOl = true; olItems.push(line.replace(/^\d+\. /, '')); continue; }
    if (/^[-*] (.+)/.test(line))  { flushOl(); inUl = true; ulItems.push(line.replace(/^[-*] /, '')); continue; }

    if (line.trim() === '') { flushLists(); continue; }

    flushLists();
    content.push({ type: 'paragraph', content: parseInline(line) });
  }

  flushLists();
  return { version: 1, type: 'doc', content };
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function extractTitle(markdown) {
  const m = markdown.match(/##\s*Bug Title\s*\n+([^\n]+)/);
  return m ? m[1].trim().replace(/^\[|\]$/g, '') : 'Bug Report';
}

function extractSeverity(markdown) {
  const m = markdown.match(/\*\*(Critical|High|Medium|Low)\*\*/);
  return m ? m[1] : 'Medium';
}

function markdownToHtml(md) {
  return md
    // Horizontal rule
    .replace(/^---+$/gm, '<hr>')
    // Headers
    .replace(/^## (.+)$/gm, '<h3>$1</h3>')
    .replace(/^### (.+)$/gm, '<h4>$1</h4>')
    // Bold & italic
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    // Links
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>')
    // Ordered list
    .replace(/^(\d+)\.\s+(.+)$/gm, '<li><span class="step-num">$1.</span> $2</li>')
    // Unordered list
    .replace(/^[-*]\s+(.+)$/gm, '<li>$1</li>')
    // Wrap consecutive <li> in <ul>
    .replace(/(<li>[\s\S]+?<\/li>\n?)+/g, match => '<ul>' + match + '</ul>')
    // Paragraphs
    .replace(/\n\n/g, '</p><p>')
    .replace(/^(?!<[hup]|<\/[hup])(.+)$/gm, '<p>$1</p>')
    // Clean up
    .replace(/<p><\/p>/g, '')
    .replace(/<p>(<[hul])/g, '$1')
    .replace(/(<\/[hul][^>]*>)<\/p>/g, '$1');
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function markdownToAzureHtml(md) {
  const lines  = md.split('\n');
  let html     = '';
  let inUl     = false;
  let inOl     = false;

  const closeList = () => {
    if (inUl) { html += '</ul>'; inUl = false; }
    if (inOl) { html += '</ol>'; inOl = false; }
  };

  const inlineFormat = str =>
    str
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g,     '<em>$1</em>')
      .replace(/`(.+?)`/g,       '<code>$1</code>')
      .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>');

  for (const raw of lines) {
    const line = raw.trimEnd();

    // Horizontal rule
    if (/^---+$/.test(line.trim())) {
      closeList();
      html += '<hr>';
      continue;
    }

    // H2 heading
    if (/^## (.+)/.test(line)) {
      closeList();
      html += `<h2>${inlineFormat(line.replace(/^## /, ''))}</h2>`;
      continue;
    }

    // H3 heading
    if (/^### (.+)/.test(line)) {
      closeList();
      html += `<h3>${inlineFormat(line.replace(/^### /, ''))}</h3>`;
      continue;
    }

    // Ordered list item
    if (/^\d+\. (.+)/.test(line)) {
      if (!inOl) { closeList(); html += '<ol>'; inOl = true; }
      html += `<li>${inlineFormat(line.replace(/^\d+\. /, ''))}</li>`;
      continue;
    }

    // Unordered list item (- or *)
    if (/^[-*] (.+)/.test(line)) {
      if (!inUl) { closeList(); html += '<ul>'; inUl = true; }
      html += `<li>${inlineFormat(line.replace(/^[-*] /, ''))}</li>`;
      continue;
    }

    // Blank line
    if (line.trim() === '') {
      closeList();
      continue;
    }

    // Regular paragraph
    closeList();
    html += `<p>${inlineFormat(line)}</p>`;
  }

  closeList();
  return html;
}

function truncate(str, maxLen) {
  return str.length <= maxLen ? str : str.substring(0, maxLen) + '…';
}

function showStatus(message, type) {
  const el = document.getElementById('statusMsg');
  el.innerHTML = message;
  el.className = 'status-msg ' + type;
  el.classList.remove('hidden');
  if (type === 'success') {
    setTimeout(() => el.classList.add('hidden'), 7000);
  }
}

function disableAnalyze() {
  const btn = document.getElementById('analyzeBtn');
  if (btn) {
    btn.disabled = true;
    btn.textContent = '⚠️ AI unavailable';
  }
}
