# 🐛 BugSnap

Chrome extension that captures bugs instantly and generates structured reports using Claude AI, then sends them directly to Azure DevOps.

## What it does

1. **Capture** — One click captures a screenshot + URL, browser, OS, resolution, and console errors automatically
2. **Annotate** — Draw and highlight the affected area on the screenshot
3. **Analyze** — Sends everything to Claude AI (claude-opus-4-6) which generates a complete, structured bug report
4. **Send** — Creates a Work Item (Bug) in Azure DevOps with one click

## Setup

### 1. Load the extension in Chrome

1. Go to `chrome://extensions/`
2. Enable **Developer mode** (top right toggle)
3. Click **Load unpacked**
4. Select the `bugsnap-extension/` folder

### 2. Configure API keys

Click the ⚙️ icon in the extension popup and fill in:

| Field | Where to get it |
|---|---|
| Claude API Key | [console.anthropic.com](https://console.anthropic.com) |
| Azure DevOps Org URL | e.g. `https://dev.azure.com/myorg` |
| Azure DevOps Project | e.g. `MyProject` |
| Azure DevOps PAT | Personal Access Token with Work Items write permission |

## Project structure

```
bugsnap-extension/
├── manifest.json       # Chrome extension manifest v3
├── popup.html/css/js   # Main extension UI
├── settings.html/css/js # API keys configuration
├── content.js          # Console error capture (injected into pages)
├── background.js       # MV3 service worker
├── icons/              # Extension icons (16, 48, 128px)
└── generate_icons.py   # Script to regenerate icons (pure Python, no deps)
```

## Tech stack

- **Frontend:** Vanilla JS, Chrome Extensions API (Manifest V3)
- **AI:** Claude claude-opus-4-6 via Anthropic API (vision + text)
- **Bug tracking:** Azure DevOps Work Items REST API v7.0
