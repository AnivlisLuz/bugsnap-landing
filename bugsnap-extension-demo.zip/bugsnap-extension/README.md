# BugSnap

Chrome extension for instant bug reporting. Captures screenshots, console logs, and generates structured reports using Claude AI — then sends them directly to Azure DevOps, Jira, or GitHub.

## What it does

1. **Capture** — One click captures a screenshot + URL, browser, OS, resolution, and console errors automatically
2. **Annotate** — Draw and highlight the affected area on the screenshot
3. **Report** — Fill in the title manually or let Claude AI auto-fill the full report
4. **Send** — Creates a Work Item / Issue in your bug tracker with one click

## Integrations

| Platform | Auth method |
|---|---|
| Azure DevOps | Microsoft OAuth (PKCE) or Personal Access Token |
| Jira | Atlassian OAuth or API Token |
| GitHub | GitHub OAuth or Personal Access Token |

## Setup

### Load the extension in Chrome

1. Go to `chrome://extensions/`
2. Enable **Developer mode** (top right toggle)
3. Click **Load unpacked**
4. Select the `bugsnap-extension/` folder

### Configure integrations

Click the settings icon in the extension and connect your bug tracker via OAuth — no API keys needed. PAT/manual mode also available for each integration.

## Project structure

```
bugsnap-extension/
├── manifest.json         # Chrome extension manifest v3
├── popup.html/css/js     # Main extension UI
├── settings.html/css/js  # Integrations configuration
├── annotation.html/css/js # Screenshot annotation editor
├── content.js            # Console error capture
├── background.js         # MV3 service worker
└── icons/                # Extension icons
```

## Tech stack

- **Frontend:** Vanilla JS, Chrome Extensions API (Manifest V3)
- **AI:** Claude Sonnet via Anthropic API (proxied through Cloudflare Worker)
- **Bug trackers:** Azure DevOps, Jira, GitHub REST APIs

## Recent improvements

- Manual bug report form — send to any integration without needing AI
- GitHub OAuth integration with repo selector
- Jira OAuth (Atlassian Cloud) integration
- Azure DevOps OAuth via Microsoft Entra ID (PKCE)
- Azure DevOps PAT mode for guest/invited org accounts
- Screenshot annotation editor (rect, arrow, pen, text, blur)
- AI usage counter with free tier limit
