// background.js — Service worker (required by Manifest V3)

chrome.runtime.onInstalled.addListener(() => {
  console.log('BugSnap installed! Click the extension icon to start reporting bugs.');
});
