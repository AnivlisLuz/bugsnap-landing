// annotation.js — BugSnap Full-Screen Annotation Editor

const HINTS = {
  rect:  'Drag to draw a rectangle. Hold Shift for a square.',
  arrow: 'Click and drag to draw an arrow pointing in any direction.',
  pen:   'Click and drag to draw freehand. Release to finish.',
  text:  'Click anywhere on the image to place a text label.',
  blur:  'Drag to blur/hide a sensitive area of the screenshot.'
};

let canvas, ctx;
let baseImage = null;
let annotations = [];  // [{type, ...params, color, lineWidth}]
let currentTool  = 'rect';
let currentColor = '#ef4444';
let currentSize  = 2;
let drawing      = false;
let startX = 0, startY = 0;
let penPoints = [];     // for pen tool
let textPending = null; // {x, y} for text tool

// ── Init ──────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', async () => {
  canvas = document.getElementById('annotationCanvas');
  ctx    = canvas.getContext('2d');

  // Load screenshot from storage
  const data = await chrome.storage.local.get(['pendingAnnotationScreenshot']);
  if (!data.pendingAnnotationScreenshot) {
    document.body.innerHTML = '<div style="color:#ef4444;padding:40px;font-size:18px;">No screenshot to annotate. Please go back to BugSnap and try again.</div>';
    return;
  }

  const img = new Image();
  img.onload = () => {
    baseImage      = img;
    canvas.width  = img.naturalWidth;
    canvas.height = img.naturalHeight;
    redraw();
    updateZoomInfo();
  };
  img.src = data.pendingAnnotationScreenshot;

  // Tool buttons
  document.querySelectorAll('.tool-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tool-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentTool = btn.dataset.tool;
      updateCanvasCursor();
      updateHint();
      cancelTextInput();
    });
  });

  // Color buttons
  document.querySelectorAll('.color-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.color-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentColor = btn.dataset.color;
    });
  });

  // Size buttons
  document.querySelectorAll('.size-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.size-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentSize = parseInt(btn.dataset.size);
    });
  });

  document.getElementById('undoBtn').addEventListener('click',  undoLast);
  document.getElementById('clearBtn').addEventListener('click', clearAll);
  document.getElementById('cancelBtn').addEventListener('click', cancelAnnotation);
  document.getElementById('saveBtn').addEventListener('click',  saveAnnotation);

  // Canvas mouse events
  canvas.addEventListener('mousedown', onMouseDown);
  canvas.addEventListener('mousemove', onMouseMove);
  canvas.addEventListener('mouseup',   onMouseUp);

  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    if (e.key === 'z' && (e.ctrlKey || e.metaKey)) { undoLast(); return; }
    if (e.key === 'Escape') { cancelTextInput(); return; }
    if (e.key === 'r' || e.key === 'R') selectTool('rect');
    if (e.key === 'a' || e.key === 'A') selectTool('arrow');
    if (e.key === 'p' || e.key === 'P') selectTool('pen');
    if (e.key === 't' || e.key === 'T') selectTool('text');
    if (e.key === 'b' || e.key === 'B') selectTool('blur');
  });

  // Text input handling
  const textInput = document.getElementById('textInput');
  textInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      commitText();
    } else if (e.key === 'Escape') {
      cancelTextInput();
    }
  });

  updateHint();
});

// ── Tool helpers ──────────────────────────────────────

function selectTool(tool) {
  document.querySelectorAll('.tool-btn').forEach(b => b.classList.remove('active'));
  document.querySelector(`[data-tool="${tool}"]`)?.classList.add('active');
  currentTool = tool;
  updateCanvasCursor();
  updateHint();
  cancelTextInput();
}

function updateCanvasCursor() {
  canvas.className = '';
  if (currentTool === 'text') canvas.classList.add('tool-text');
  if (currentTool === 'blur') canvas.classList.add('tool-blur');
}

function updateHint() {
  document.getElementById('hintText').textContent = HINTS[currentTool] || '';
}

function updateZoomInfo() {
  if (!baseImage) return;
  const rect = canvas.getBoundingClientRect();
  const pct  = Math.round((rect.width / canvas.width) * 100);
  document.getElementById('zoomInfo').textContent = `${canvas.width}×${canvas.height}px — displayed at ${pct}%`;
}

// ── Canvas coordinate helpers ─────────────────────────

function getPos(e) {
  const rect   = canvas.getBoundingClientRect();
  const scaleX = canvas.width  / rect.width;
  const scaleY = canvas.height / rect.height;
  return {
    x: (e.clientX - rect.left) * scaleX,
    y: (e.clientY - rect.top)  * scaleY
  };
}

// ── Mouse Events ──────────────────────────────────────

function onMouseDown(e) {
  if (e.button !== 0) return;
  const pos = getPos(e);

  if (currentTool === 'text') {
    placeTextInput(e.clientX, e.clientY, pos.x, pos.y);
    return;
  }

  drawing  = true;
  startX   = pos.x;
  startY   = pos.y;
  penPoints = [pos];
}

function onMouseMove(e) {
  if (!drawing) return;
  const pos = getPos(e);

  if (currentTool === 'pen') {
    penPoints.push(pos);
  }

  redraw(getPreview(pos));
}

function onMouseUp(e) {
  if (!drawing) return;
  drawing = false;
  const pos = getPos(e);

  if (currentTool === 'pen') {
    penPoints.push(pos);
    if (penPoints.length > 2) {
      annotations.push({ type: 'pen', points: [...penPoints], color: currentColor, lineWidth: currentSize });
    }
    penPoints = [];
    redraw();
    return;
  }

  const dx = pos.x - startX;
  const dy = pos.y - startY;

  if (Math.abs(dx) < 3 && Math.abs(dy) < 3 && currentTool !== 'pen') {
    redraw();
    return;
  }

  if (currentTool === 'rect') {
    annotations.push({ type: 'rect', x: startX, y: startY, w: dx, h: dy, color: currentColor, lineWidth: currentSize });
  } else if (currentTool === 'arrow') {
    annotations.push({ type: 'arrow', x1: startX, y1: startY, x2: pos.x, y2: pos.y, color: currentColor, lineWidth: currentSize });
  } else if (currentTool === 'blur') {
    const bx = dx < 0 ? pos.x : startX;
    const by = dy < 0 ? pos.y : startY;
    annotations.push({ type: 'blur', x: bx, y: by, w: Math.abs(dx), h: Math.abs(dy) });
  }

  redraw();
}

// ── Preview while dragging ────────────────────────────

function getPreview(pos) {
  if (!drawing) return null;
  const dx = pos.x - startX;
  const dy = pos.y - startY;

  if (currentTool === 'rect') {
    return { type: 'rect', x: startX, y: startY, w: dx, h: dy, color: currentColor, lineWidth: currentSize, preview: true };
  }
  if (currentTool === 'arrow') {
    return { type: 'arrow', x1: startX, y1: startY, x2: pos.x, y2: pos.y, color: currentColor, lineWidth: currentSize, preview: true };
  }
  if (currentTool === 'pen') {
    return { type: 'pen', points: [...penPoints, pos], color: currentColor, lineWidth: currentSize, preview: true };
  }
  if (currentTool === 'blur') {
    const bx = dx < 0 ? pos.x : startX;
    const by = dy < 0 ? pos.y : startY;
    return { type: 'blur', x: bx, y: by, w: Math.abs(dx), h: Math.abs(dy), preview: true };
  }
  return null;
}

// ── Redraw ────────────────────────────────────────────

function redraw(preview = null) {
  if (!baseImage) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(baseImage, 0, 0, canvas.width, canvas.height);

  for (const ann of annotations) drawAnnotation(ann, false);
  if (preview) drawAnnotation(preview, true);
}

function drawAnnotation(ann, isPreview) {
  ctx.save();

  if (isPreview) {
    ctx.globalAlpha = 0.75;
    ctx.setLineDash([6, 3]);
  }

  switch (ann.type) {
    case 'rect':  drawRect(ann);  break;
    case 'arrow': drawArrow(ann); break;
    case 'pen':   drawPen(ann);   break;
    case 'text':  drawText(ann);  break;
    case 'blur':  drawBlur(ann);  break;
  }

  ctx.restore();
}

// ── Drawing functions ─────────────────────────────────

function drawRect(ann) {
  ctx.strokeStyle = ann.color;
  ctx.lineWidth   = ann.lineWidth;
  ctx.shadowColor = 'rgba(0,0,0,0.4)';
  ctx.shadowBlur  = 4;
  ctx.strokeRect(ann.x, ann.y, ann.w, ann.h);
}

function drawArrow(ann) {
  const { x1, y1, x2, y2, color, lineWidth } = ann;
  const headLen = Math.max(16, lineWidth * 5);
  const angle   = Math.atan2(y2 - y1, x2 - x1);

  ctx.strokeStyle = color;
  ctx.fillStyle   = color;
  ctx.lineWidth   = lineWidth;
  ctx.shadowColor = 'rgba(0,0,0,0.4)';
  ctx.shadowBlur  = 4;
  ctx.lineCap     = 'round';

  // Shaft
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();

  // Arrowhead
  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(
    x2 - headLen * Math.cos(angle - Math.PI / 7),
    y2 - headLen * Math.sin(angle - Math.PI / 7)
  );
  ctx.lineTo(
    x2 - headLen * Math.cos(angle + Math.PI / 7),
    y2 - headLen * Math.sin(angle + Math.PI / 7)
  );
  ctx.closePath();
  ctx.fill();
}

function drawPen(ann) {
  if (ann.points.length < 2) return;
  ctx.strokeStyle = ann.color;
  ctx.lineWidth   = ann.lineWidth;
  ctx.lineCap     = 'round';
  ctx.lineJoin    = 'round';
  ctx.shadowColor = 'rgba(0,0,0,0.3)';
  ctx.shadowBlur  = 2;
  ctx.beginPath();
  ctx.moveTo(ann.points[0].x, ann.points[0].y);
  for (let i = 1; i < ann.points.length; i++) {
    ctx.lineTo(ann.points[i].x, ann.points[i].y);
  }
  ctx.stroke();
}

function drawText(ann) {
  const fontSize = Math.max(16, ann.lineWidth * 6);
  ctx.font      = `bold ${fontSize}px sans-serif`;
  ctx.fillStyle = ann.color;
  ctx.shadowColor = 'rgba(0,0,0,0.6)';
  ctx.shadowBlur  = 3;
  ctx.shadowOffsetX = 1;
  ctx.shadowOffsetY = 1;

  const lines = ann.text.split('\n');
  lines.forEach((line, i) => {
    ctx.fillText(line, ann.x, ann.y + i * (fontSize + 4));
  });
}

function drawBlur(ann) {
  if (ann.w < 4 || ann.h < 4) return;

  // Pixelate the area by scaling down and back up
  const PIXEL_SIZE = 12;
  const srcData = ctx.getImageData(ann.x, ann.y, ann.w, ann.h);

  // Draw tiny version then scale up
  const offscreen = document.createElement('canvas');
  const sw = Math.max(1, Math.floor(ann.w / PIXEL_SIZE));
  const sh = Math.max(1, Math.floor(ann.h / PIXEL_SIZE));
  offscreen.width  = sw;
  offscreen.height = sh;
  const offCtx = offscreen.getContext('2d');
  offCtx.putImageData(srcData, 0, 0);

  // Scale back up using nearest-neighbor (pixelate effect)
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(offscreen, 0, 0, sw, sh, ann.x, ann.y, ann.w, ann.h);
  ctx.imageSmoothingEnabled = true;

  // Semi-transparent dark overlay
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.fillRect(ann.x, ann.y, ann.w, ann.h);
}

// ── Text tool ─────────────────────────────────────────

function placeTextInput(clientX, clientY, canvasX, canvasY) {
  cancelTextInput();
  textPending = { canvasX, canvasY };

  const input = document.getElementById('textInput');
  input.style.left   = clientX + 'px';
  input.style.top    = clientY + 'px';
  input.style.color  = currentColor;
  input.value        = '';
  input.classList.remove('hidden');
  input.focus();
}

function commitText() {
  const input = document.getElementById('textInput');
  const text  = input.value.trim();
  if (text && textPending) {
    annotations.push({
      type: 'text',
      x: textPending.canvasX,
      y: textPending.canvasY,
      text,
      color: currentColor,
      lineWidth: currentSize
    });
    redraw();
  }
  cancelTextInput();
}

function cancelTextInput() {
  const input = document.getElementById('textInput');
  input.classList.add('hidden');
  input.value   = '';
  textPending   = null;
}

// ── Actions ───────────────────────────────────────────

function undoLast() {
  if (annotations.length > 0) {
    annotations.pop();
    redraw();
  }
}

function clearAll() {
  if (annotations.length === 0) return;
  if (confirm('Clear all annotations?')) {
    annotations = [];
    redraw();
  }
}

async function saveAnnotation() {
  commitText(); // commit any pending text first

  const dataUrl = canvas.toDataURL('image/png');

  await chrome.storage.local.set({
    annotatedScreenshot: dataUrl,
    pendingAnnotationScreenshot: null
  });

  window.close();
}

async function cancelAnnotation() {
  await chrome.storage.local.remove(['pendingAnnotationScreenshot']);
  window.close();
}
