// settings.js — BugSnap Settings Page Logic

const WORKER_URL = 'https://bugsnap-proxy.luzchoquej.workers.dev';
const GITHUB_CLIENT_ID = 'Ov23liRI4qBeg2YOsYdX';
const JIRA_CLIENT_ID   = 'BfkEzZI8zHLMm0AA4XhJ6m6cm9mM4MM4';
const GITHUB_OAUTH_SCOPES = 'repo';

// Microsoft Entra ID (Azure AD) — PKCE flow, no client secret needed
const ENTRA_CLIENT_ID   = '726efb90-7519-49bc-81d6-fb3ca827fd1a';
const ENTRA_TOKEN_URL   = 'https://login.microsoftonline.com/common/oauth2/v2.0/token';
// Azure DevOps resource ID + offline_access for refresh token
const AZURE_DEVOPS_SCOPE = '499b84ac-1321-427f-aa17-267ca6975798/user_impersonation offline_access';

// Generate PKCE code_verifier + code_challenge (SHA-256)
async function generatePKCE() {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  const verifier = btoa(String.fromCharCode(...array))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');

  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier));
  const challenge = btoa(String.fromCharCode(...new Uint8Array(digest)))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');

  return { verifier, challenge };
}

// ── GitHub OAuth Functions ────────────────────────────

async function initiateGithubOAuth() {
  const btn = document.getElementById('githubConnectBtn');
  const statusEl = document.getElementById('githubConnectStatus');
  btn.disabled = true;
  statusEl.textContent = 'Opening GitHub authorization...';
  statusEl.style.color = '#94a3b8';

  const state = crypto.randomUUID();
  const redirectUrl = chrome.identity.getRedirectURL('callback');
  const authUrl = `https://github.com/login/oauth/authorize?client_id=${GITHUB_CLIENT_ID}&redirect_uri=${encodeURIComponent(redirectUrl)}&scope=${GITHUB_OAUTH_SCOPES}&state=${state}`;

  try {
    const responseUrl = await new Promise((resolve, reject) => {
      chrome.identity.launchWebAuthFlow(
        { url: authUrl, interactive: true },
        (callbackUrl) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(callbackUrl);
          }
        }
      );
    });

    const params = new URL(responseUrl).searchParams;
    const code = params.get('code');
    const returnedState = params.get('state');

    if (returnedState !== state) {
      throw new Error('State mismatch — possible CSRF attack');
    }
    if (!code) {
      throw new Error('No authorization code received');
    }

    statusEl.textContent = 'Exchanging code for token...';

    const tokenRes = await fetch(`${WORKER_URL}/github/oauth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code })
    });

    const tokenData = await tokenRes.json();
    if (!tokenRes.ok || tokenData.error) {
      throw new Error(tokenData.error || 'Token exchange failed');
    }

    statusEl.textContent = 'Fetching your GitHub profile...';

    const userRes = await fetch('https://api.github.com/user', {
      headers: {
        'Authorization': `Bearer ${tokenData.access_token}`,
        'Accept': 'application/vnd.github+json'
      }
    });
    if (!userRes.ok) throw new Error('Failed to fetch GitHub user info');
    const user = await userRes.json();

    await chrome.storage.sync.set({
      githubOAuthToken: tokenData.access_token,
      githubOAuthUser: { login: user.login, avatar_url: user.avatar_url }
    });

    showGithubConnected(user.login, user.avatar_url);
    await setActiveProvider('github');
    await loadGithubRepos(tokenData.access_token);
    statusEl.textContent = '';

  } catch (err) {
    if (err.message.includes('canceled') || err.message.includes('closed')) {
      statusEl.textContent = 'Authorization was canceled.';
    } else {
      statusEl.textContent = 'Connection failed: ' + err.message;
    }
    statusEl.style.color = '#ef4444';
  } finally {
    btn.disabled = false;
  }
}

function showGithubConnected(username, avatarUrl) {
  document.getElementById('githubConnectSection').classList.add('hidden');
  document.getElementById('githubOAuthStatus').classList.remove('hidden');
  document.getElementById('githubRepoOAuthSection').classList.remove('hidden');

  document.getElementById('githubUsername').textContent = username;
  if (avatarUrl) {
    document.getElementById('githubAvatar').style.backgroundImage = `url(${avatarUrl})`;
  }
}

function showGithubDisconnected() {
  document.getElementById('githubConnectSection').classList.remove('hidden');
  document.getElementById('githubOAuthStatus').classList.add('hidden');
  document.getElementById('githubRepoOAuthSection').classList.add('hidden');
  document.getElementById('githubConnectStatus').textContent = '';
}

async function disconnectGithub() {
  await chrome.storage.sync.remove(['githubOAuthToken', 'githubOAuthUser', 'githubRepoFullName']);
  showGithubDisconnected();
  const select = document.getElementById('githubRepoSelect');
  select.innerHTML = '<option value="">— Connect GitHub first —</option>';
}

async function loadGithubRepos(token) {
  const select = document.getElementById('githubRepoSelect');
  const refreshBtn = document.getElementById('refreshReposBtn');

  select.innerHTML = '<option value="">Loading repositories...</option>';
  refreshBtn.disabled = true;

  try {
    const res = await fetch('https://api.github.com/user/repos?sort=pushed&per_page=100&affiliation=owner,collaborator,organization_member', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github+json'
      }
    });

    if (!res.ok) throw new Error(`GitHub API error: ${res.status}`);

    const repos = await res.json();

    select.innerHTML = '<option value="">— Select a repository —</option>';
    repos.forEach(repo => {
      const opt = document.createElement('option');
      opt.value = repo.full_name;
      opt.textContent = repo.full_name + (repo.private ? ' 🔒' : '');
      select.appendChild(opt);
    });

    // Restore previously selected repo
    const saved = await chrome.storage.sync.get(['githubRepoFullName']);
    if (saved.githubRepoFullName) {
      if ([...select.options].some(o => o.value === saved.githubRepoFullName)) {
        select.value = saved.githubRepoFullName;
      }
    }
  } catch (err) {
    select.innerHTML = '<option value="">Error loading repos</option>';
    console.error('Failed to load GitHub repos:', err);
  } finally {
    refreshBtn.disabled = false;
  }
}

// ── Azure DevOps OAuth Functions ──────────────────────

async function initiateAzureOAuth() {
  const btn = document.getElementById('azureConnectBtn');
  const statusEl = document.getElementById('azureConnectStatus');
  btn.disabled = true;
  statusEl.textContent = 'Opening Microsoft authorization...';
  statusEl.style.color = '#94a3b8';

  const state = crypto.randomUUID();
  const redirectUrl = chrome.identity.getRedirectURL('callback');
  const { verifier, challenge } = await generatePKCE();

  const authUrl = `https://login.microsoftonline.com/common/oauth2/v2.0/authorize`
    + `?client_id=${ENTRA_CLIENT_ID}`
    + `&response_type=code`
    + `&redirect_uri=${encodeURIComponent(redirectUrl)}`
    + `&scope=${encodeURIComponent(AZURE_DEVOPS_SCOPE)}`
    + `&state=${state}`
    + `&code_challenge=${challenge}`
    + `&code_challenge_method=S256`;

  try {
    const responseUrl = await new Promise((resolve, reject) => {
      chrome.identity.launchWebAuthFlow(
        { url: authUrl, interactive: true },
        (callbackUrl) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(callbackUrl);
        }
      );
    });

    const params = new URL(responseUrl).searchParams;
    const code   = params.get('code');
    const returnedState = params.get('state');

    if (returnedState !== state) throw new Error('State mismatch — possible CSRF attack');
    if (!code) throw new Error('No authorization code received');

    statusEl.textContent = 'Exchanging code for token...';

    // PKCE token exchange directly with Microsoft — no client secret needed
    const tokenForm = new URLSearchParams({
      client_id:     ENTRA_CLIENT_ID,
      code:          code,
      redirect_uri:  redirectUrl,
      grant_type:    'authorization_code',
      code_verifier: verifier,
      scope:         AZURE_DEVOPS_SCOPE
    });

    const tokenRes = await fetch(ENTRA_TOKEN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: tokenForm.toString()
    });

    const tokenData = await tokenRes.json();
    if (!tokenRes.ok || tokenData.error) {
      throw new Error(tokenData.error_description || tokenData.error || 'Token exchange failed');
    }

    const expiry = Date.now() + (tokenData.expires_in - 60) * 1000;

    statusEl.textContent = 'Fetching your Azure profile...';

    const profileRes = await fetch('https://app.vssps.visualstudio.com/_apis/profile/profiles/me?api-version=7.0', {
      headers: { 'Authorization': `Bearer ${tokenData.access_token}`, 'Accept': 'application/json' }
    });
    if (!profileRes.ok) throw new Error('Failed to fetch Azure profile');
    const profile = await profileRes.json();

    await chrome.storage.sync.set({
      azureOAuthToken:        tokenData.access_token,
      azureOAuthRefreshToken: tokenData.refresh_token,
      azureOAuthExpiry:       expiry,
      azureOAuthUser:         { displayName: profile.displayName, emailAddress: profile.emailAddress }
    });

    showAzureConnected(profile.displayName, profile.emailAddress);
    await setActiveProvider('azure');
    await loadAzureOrgs(tokenData.access_token);
    statusEl.textContent = '';

  } catch (err) {
    statusEl.textContent = (err.message.includes('canceled') || err.message.includes('closed'))
      ? 'Authorization was canceled.'
      : 'Connection failed: ' + err.message;
    statusEl.style.color = '#ef4444';
  } finally {
    btn.disabled = false;
  }
}

// ── Active Provider ───────────────────────────────────────────────────────────

const PROVIDER_LABELS = { azure: 'Azure DevOps', jira: 'Jira', github: 'GitHub' };

async function setActiveProvider(provider) {
  await chrome.storage.sync.set({ activeProvider: provider });
  updateProviderUI(provider);
}

async function clearActiveProvider() {
  await chrome.storage.sync.remove(['activeProvider']);
  updateProviderUI(null);
}

function updateProviderUI(provider) {
  const cards    = { azure: 'azureCard', jira: 'jiraCard', github: 'githubCard' };
  const selector = document.getElementById('providerSelectorSection');
  const switchSection = document.getElementById('switchProviderSection');
  const activeLabel   = document.getElementById('activeProviderLabel');

  if (!provider) {
    // Hide all integration cards, show compact selector
    Object.values(cards).forEach(id => document.getElementById(id).classList.add('hidden'));
    selector.classList.remove('hidden');
    switchSection.classList.add('hidden');
  } else {
    // Hide selector, show only the active card, show switch banner
    selector.classList.add('hidden');
    Object.entries(cards).forEach(([key, id]) => {
      document.getElementById(id).classList.toggle('hidden', key !== provider);
    });
    activeLabel.textContent = 'Active: ' + (PROVIDER_LABELS[provider] || provider);
    switchSection.classList.remove('hidden');
  }
}

// ─────────────────────────────────────────────────────────────────────────────

function showAzureConnected(displayName, email) {
  document.getElementById('azureConnectSection').classList.add('hidden');
  document.getElementById('azureOAuthStatus').classList.remove('hidden');
  document.getElementById('azureOAuthSection').classList.remove('hidden');
  document.getElementById('azureManualModeField').classList.remove('hidden');
  document.getElementById('azureUsername').textContent = displayName || '—';
  document.getElementById('azureUserEmail').textContent = email || '';
}

function showAzureDisconnected() {
  document.getElementById('azureConnectSection').classList.remove('hidden');
  document.getElementById('azureManualModeField').classList.remove('hidden');
  document.getElementById('azureOAuthStatus').classList.add('hidden');
  document.getElementById('azureOAuthSection').classList.add('hidden');
  document.getElementById('azureConnectStatus').textContent = '';
}

async function disconnectAzure() {
  await chrome.storage.sync.remove([
    'azureOAuthToken', 'azureOAuthRefreshToken', 'azureOAuthExpiry',
    'azureOAuthUser', 'azureOAuthOrg', 'azureOAuthProject'
  ]);
  showAzureDisconnected();
  document.getElementById('azureOrgSelect').innerHTML    = '<option value="">— Connect Azure first —</option>';
  document.getElementById('azureProjectSelect').innerHTML = '<option value="">— Select an organization first —</option>';
}

async function getAzureTokenForSettings() {
  const saved = await chrome.storage.sync.get(['azureOAuthToken', 'azureOAuthRefreshToken', 'azureOAuthExpiry']);
  if (!saved.azureOAuthToken) return null;

  // Token still valid
  if (saved.azureOAuthExpiry && Date.now() < saved.azureOAuthExpiry) {
    return saved.azureOAuthToken;
  }

  // Token expired — refresh directly with Microsoft (no Worker needed)
  if (!saved.azureOAuthRefreshToken) return null;
  try {
    const tokenForm = new URLSearchParams({
      client_id:     ENTRA_CLIENT_ID,
      grant_type:    'refresh_token',
      refresh_token: saved.azureOAuthRefreshToken,
      scope:         AZURE_DEVOPS_SCOPE
    });

    const res = await fetch(ENTRA_TOKEN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: tokenForm.toString()
    });
    const data = await res.json();
    if (!res.ok || data.error) return null;

    const expiry = Date.now() + (data.expires_in - 60) * 1000;
    await chrome.storage.sync.set({
      azureOAuthToken:        data.access_token,
      azureOAuthRefreshToken: data.refresh_token,
      azureOAuthExpiry:       expiry
    });
    return data.access_token;
  } catch (_) {
    return null;
  }
}

async function loadAzureOrgs(token) {
  const select = document.getElementById('azureOrgSelect');
  const refreshBtn = document.getElementById('refreshOrgsBtn');
  select.innerHTML = '<option value="">Loading organizations...</option>';
  refreshBtn.disabled = true;

  try {
    // Get user profile to get memberId
    const profileRes = await fetch('https://app.vssps.visualstudio.com/_apis/profile/profiles/me?api-version=7.0', {
      headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
    });
    if (!profileRes.ok) throw new Error(`Profile API error: ${profileRes.status}`);
    const profile = await profileRes.json();

    // Get organizations using memberId
    const orgsRes = await fetch(`https://app.vssps.visualstudio.com/_apis/accounts?memberId=${profile.id}&api-version=7.0`, {
      headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
    });
    if (!orgsRes.ok) throw new Error(`Orgs API error: ${orgsRes.status}`);
    const orgsData = await orgsRes.json();
    const orgs = orgsData.value || [];

    select.innerHTML = '<option value="">— Select an organization —</option>';
    orgs.forEach(org => {
      const opt = document.createElement('option');
      opt.value = org.accountName;
      opt.textContent = org.accountName;
      select.appendChild(opt);
    });

    // Restore saved org
    const saved = await chrome.storage.sync.get(['azureOAuthOrg']);
    if (saved.azureOAuthOrg && [...select.options].some(o => o.value === saved.azureOAuthOrg)) {
      select.value = saved.azureOAuthOrg;
      await loadAzureProjects(token, saved.azureOAuthOrg);
    }
  } catch (err) {
    select.innerHTML = '<option value="">Error loading organizations</option>';
    console.error('Failed to load Azure orgs:', err);
  } finally {
    refreshBtn.disabled = false;
  }
}

async function loadAzureProjects(token, org, prefetchedProjects = null) {
  const select = document.getElementById('azureProjectSelect');
  select.innerHTML = '<option value="">Loading projects...</option>';

  try {
    let projects;
    if (prefetchedProjects !== null) {
      projects = prefetchedProjects;
    } else {
      const res = await fetch(`https://dev.azure.com/${org}/_apis/projects?api-version=7.0`, {
        headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
      });
      if (!res.ok) throw new Error(`Projects API error: ${res.status}`);
      const data = await res.json();
      projects = data.value || [];
    }

    select.innerHTML = '<option value="">— Select a project —</option>';
    projects.forEach(proj => {
      const opt = document.createElement('option');
      opt.value = proj.name;
      opt.textContent = proj.name;
      select.appendChild(opt);
    });

    // Restore saved project
    const saved = await chrome.storage.sync.get(['azureOAuthProject']);
    if (saved.azureOAuthProject && [...select.options].some(o => o.value === saved.azureOAuthProject)) {
      select.value = saved.azureOAuthProject;
    }
  } catch (err) {
    select.innerHTML = '<option value="">Error loading projects</option>';
    console.error('Failed to load Azure projects:', err);
  }
}

// ── Jira OAuth Functions ───────────────────────────────

async function initiateJiraOAuth() {
  const btn = document.getElementById('jiraConnectBtn');
  const statusEl = document.getElementById('jiraConnectStatus');
  btn.disabled = true;
  statusEl.textContent = 'Opening Atlassian authorization...';
  statusEl.style.color = '#94a3b8';

  const state = crypto.randomUUID();
  const redirectUrl = chrome.identity.getRedirectURL('callback');
  const scopes = 'read:jira-user read:jira-work write:jira-work';

  const authUrl = 'https://auth.atlassian.com/authorize'
    + `?audience=api.atlassian.com`
    + `&client_id=${JIRA_CLIENT_ID}`
    + `&scope=${encodeURIComponent(scopes)}`
    + `&redirect_uri=${encodeURIComponent(redirectUrl)}`
    + `&state=${state}`
    + `&response_type=code`
    + `&prompt=consent`;

  try {
    const responseUrl = await new Promise((resolve, reject) => {
      chrome.identity.launchWebAuthFlow(
        { url: authUrl, interactive: true },
        (callbackUrl) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(callbackUrl);
        }
      );
    });

    const params = new URL(responseUrl).searchParams;
    const code = params.get('code');
    const returnedState = params.get('state');

    if (returnedState !== state) throw new Error('State mismatch — possible CSRF attack');
    if (!code) throw new Error('No authorization code received');

    statusEl.textContent = 'Exchanging code for token...';

    const tokenRes = await fetch(`${WORKER_URL}/jira/oauth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code })
    });

    const tokenData = await tokenRes.json();
    if (!tokenRes.ok || tokenData.error) {
      throw new Error(tokenData.error || 'Token exchange failed');
    }

    const expiry = Date.now() + (tokenData.expires_in - 60) * 1000;

    statusEl.textContent = 'Fetching your Jira profile...';

    // Get user info (best-effort — requires read:account scope)
    let userName = 'Jira User';
    let userEmail = '';
    try {
      const userRes = await fetch('https://api.atlassian.com/me', {
        headers: { 'Authorization': `Bearer ${tokenData.access_token}`, 'Accept': 'application/json' }
      });
      if (userRes.ok) {
        const user = await userRes.json();
        userName = user.name || user.nickname || userName;
        userEmail = user.email || '';
      }
    } catch (_) {}

    await chrome.storage.sync.set({
      jiraOAuthToken:        tokenData.access_token,
      jiraOAuthRefreshToken: tokenData.refresh_token,
      jiraOAuthExpiry:       expiry,
      jiraOAuthUser:         { displayName: userName, email: userEmail }
    });

    showJiraConnected(userName, userEmail);
    await setActiveProvider('jira');
    await loadJiraSites(tokenData.access_token);
    statusEl.textContent = '';

  } catch (err) {
    statusEl.textContent = (err.message.includes('canceled') || err.message.includes('closed'))
      ? 'Authorization was canceled.'
      : 'Connection failed: ' + err.message;
    statusEl.style.color = '#ef4444';
  } finally {
    btn.disabled = false;
  }
}

function showJiraConnected(displayName, email) {
  document.getElementById('jiraConnectSection').classList.add('hidden');
  document.getElementById('jiraManualModeField').classList.add('hidden');
  document.getElementById('jiraOAuthStatus').classList.remove('hidden');
  document.getElementById('jiraOAuthSection').classList.remove('hidden');
  document.getElementById('jiraUsername').textContent = displayName || '—';
  document.getElementById('jiraUserEmail').textContent = email || '';
}

function showJiraDisconnected() {
  document.getElementById('jiraConnectSection').classList.remove('hidden');
  document.getElementById('jiraManualModeField').classList.remove('hidden');
  document.getElementById('jiraOAuthStatus').classList.add('hidden');
  document.getElementById('jiraOAuthSection').classList.add('hidden');
  document.getElementById('jiraConnectStatus').textContent = '';
}

async function disconnectJira() {
  await chrome.storage.sync.remove([
    'jiraOAuthToken', 'jiraOAuthRefreshToken', 'jiraOAuthExpiry',
    'jiraOAuthUser', 'jiraOAuthCloudId', 'jiraOAuthSiteUrl', 'jiraOAuthSiteName',
    'jiraOAuthProject', 'jiraOAuthProjectId', 'jiraOAuthIssueType'
  ]);
  showJiraDisconnected();
  document.getElementById('jiraSiteSelect').innerHTML = '<option value="">— Connect Jira first —</option>';
  document.getElementById('jiraProjectSelect').innerHTML = '<option value="">— Select a site first —</option>';
  document.getElementById('jiraIssueTypeOAuth').innerHTML = '<option value="">— Select a project first —</option>';
}

async function getJiraTokenForSettings() {
  const saved = await chrome.storage.sync.get(['jiraOAuthToken', 'jiraOAuthRefreshToken', 'jiraOAuthExpiry']);
  if (!saved.jiraOAuthToken) return null;

  if (saved.jiraOAuthExpiry && Date.now() < saved.jiraOAuthExpiry) {
    return saved.jiraOAuthToken;
  }

  if (!saved.jiraOAuthRefreshToken) return null;

  try {
    const res = await fetch(`${WORKER_URL}/jira/oauth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: saved.jiraOAuthRefreshToken })
    });
    const data = await res.json();
    if (!res.ok || data.error) return null;

    const expiry = Date.now() + (data.expires_in - 60) * 1000;
    await chrome.storage.sync.set({
      jiraOAuthToken:        data.access_token,
      jiraOAuthRefreshToken: data.refresh_token,
      jiraOAuthExpiry:       expiry
    });
    return data.access_token;
  } catch (_) {
    return null;
  }
}

async function loadJiraSites(token) {
  const select = document.getElementById('jiraSiteSelect');
  const refreshBtn = document.getElementById('refreshJiraSitesBtn');
  select.innerHTML = '<option value="">Loading sites...</option>';
  refreshBtn.disabled = true;

  try {
    const res = await fetch('https://api.atlassian.com/oauth/token/accessible-resources', {
      headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
    });
    if (!res.ok) throw new Error(`Accessible resources error: ${res.status}`);
    const sites = await res.json();

    select.innerHTML = '<option value="">— Select a Jira site —</option>';
    sites.forEach(site => {
      const opt = document.createElement('option');
      opt.value = site.id; // cloudId
      opt.textContent = site.name;
      opt.dataset.url = site.url;
      select.appendChild(opt);
    });

    // Restore saved site
    const saved = await chrome.storage.sync.get(['jiraOAuthCloudId']);
    if (saved.jiraOAuthCloudId && [...select.options].some(o => o.value === saved.jiraOAuthCloudId)) {
      select.value = saved.jiraOAuthCloudId;
      await loadJiraProjects(token, saved.jiraOAuthCloudId);
    }
  } catch (err) {
    select.innerHTML = '<option value="">Error loading sites</option>';
    console.error('Failed to load Jira sites:', err);
  } finally {
    refreshBtn.disabled = false;
  }
}

async function loadJiraProjects(token, cloudId) {
  const select = document.getElementById('jiraProjectSelect');
  select.innerHTML = '<option value="">Loading projects...</option>';

  try {
    const res = await fetch(`https://api.atlassian.com/ex/jira/${cloudId}/rest/api/3/project/search?maxResults=100`, {
      headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
    });
    if (!res.ok) throw new Error(`Projects API error: ${res.status}`);
    const data = await res.json();
    const projects = data.values || [];

    select.innerHTML = '<option value="">— Select a project —</option>';
    projects.forEach(proj => {
      const opt = document.createElement('option');
      opt.value = proj.key;
      opt.textContent = `${proj.name} (${proj.key})`;
      opt.dataset.id = proj.id;
      select.appendChild(opt);
    });

    // Restore saved project
    const saved = await chrome.storage.sync.get(['jiraOAuthProject']);
    if (saved.jiraOAuthProject && [...select.options].some(o => o.value === saved.jiraOAuthProject)) {
      select.value = saved.jiraOAuthProject;
    }
  } catch (err) {
    select.innerHTML = '<option value="">Error loading projects</option>';
    console.error('Failed to load Jira projects:', err);
  }
}

async function loadJiraIssueTypesOAuth(token, cloudId, projectKey) {
  const select = document.getElementById('jiraIssueTypeOAuth');
  const btn = document.getElementById('loadIssueTypesOAuthBtn');
  select.innerHTML = '<option value="">Loading issue types...</option>';
  btn.disabled = true;

  try {
    const res = await fetch(`https://api.atlassian.com/ex/jira/${cloudId}/rest/api/3/issue/createmeta/${projectKey}/issuetypes`, {
      headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
    });
    if (!res.ok) throw new Error(`Issue types API error: ${res.status}`);
    const data = await res.json();
    const types = data.issueTypes || data.values || [];

    select.innerHTML = '<option value="">— Select an issue type —</option>';
    types.forEach(t => {
      const opt = document.createElement('option');
      opt.value = t.name;
      opt.textContent = t.name + (t.subtask ? ' (subtask)' : '');
      select.appendChild(opt);
    });

    // Restore saved issue type
    const saved = await chrome.storage.sync.get(['jiraOAuthIssueType']);
    if (saved.jiraOAuthIssueType && [...select.options].some(o => o.value === saved.jiraOAuthIssueType)) {
      select.value = saved.jiraOAuthIssueType;
    }
  } catch (err) {
    select.innerHTML = '<option value="">Error loading issue types</option>';
    console.error('Failed to load Jira issue types:', err);
  } finally {
    btn.disabled = false;
  }
}

// ── Main Init ─────────────────────────────────────────

document.addEventListener('DOMContentLoaded', async () => {
  // Load saved settings
  const saved = await chrome.storage.sync.get([
    'activeProvider',
    'azureOrg', 'azureProject', 'azurePat', 'azureWorkItemType', 'azureAreaPath', 'azureAssignedTo',
    'azureOAuthToken', 'azureOAuthUser', 'azureOAuthOrg', 'azureOAuthProject', 'azureManualMode',
    'jiraDomain', 'jiraEmail', 'jiraToken', 'jiraProjectKey', 'jiraIssueType', 'jiraAssignee',
    'jiraOAuthToken', 'jiraOAuthUser', 'jiraOAuthCloudId', 'jiraOAuthProject', 'jiraOAuthIssueType',
    'jiraOAuthAssignee', 'jiraManualMode',
    'githubRepo', 'githubToken', 'githubLabels', 'githubAssignee',
    'githubOAuthToken', 'githubOAuthUser', 'githubRepoFullName', 'githubManualMode',
    'verboseNetwork'
  ]);

  // Apply active provider UI (show/hide integration cards)
  updateProviderUI(saved.activeProvider || null);

  // Restore Azure manual settings
  if (saved.azureOrg)          document.getElementById('azureOrg').value          = saved.azureOrg;
  if (saved.azureProject)      document.getElementById('azureProject').value      = saved.azureProject;
  if (saved.azurePat)          document.getElementById('azurePat').value          = saved.azurePat;
  if (saved.azureWorkItemType) document.getElementById('azureWorkItemType').value = saved.azureWorkItemType;
  if (saved.azureAreaPath)     document.getElementById('azureAreaPath').value     = saved.azureAreaPath;
  if (saved.azureAssignedTo)   document.getElementById('azureAssignedTo').value   = saved.azureAssignedTo;

  // Restore Azure OAuth state
  if (saved.azureManualMode) {
    document.getElementById('azureManualMode').checked = true;
    document.getElementById('azureManualSection').classList.remove('hidden');
    document.getElementById('azureOAuthOnlyFields').classList.add('hidden');
    document.getElementById('azureConnectSection').classList.add('hidden');
  } else if (saved.azureOAuthToken && saved.azureOAuthUser) {
    showAzureConnected(saved.azureOAuthUser.displayName, saved.azureOAuthUser.emailAddress);
    const token = await getAzureTokenForSettings();
    if (token) await loadAzureOrgs(token);
  }

  // Restore Jira OAuth state
  if (saved.jiraManualMode) {
    document.getElementById('jiraManualMode').checked = true;
    document.getElementById('jiraManualSection').classList.remove('hidden');
    document.getElementById('jiraConnectSection').classList.add('hidden');
  } else if (saved.jiraOAuthToken && saved.jiraOAuthUser) {
    showJiraConnected(saved.jiraOAuthUser.displayName, saved.jiraOAuthUser.email);
    const token = await getJiraTokenForSettings();
    if (token) await loadJiraSites(token);
  }

  // Restore Jira manual settings
  if (saved.jiraDomain)        document.getElementById('jiraDomain').value        = saved.jiraDomain;
  if (saved.jiraEmail)         document.getElementById('jiraEmail').value         = saved.jiraEmail;
  if (saved.jiraToken)         document.getElementById('jiraToken').value         = saved.jiraToken;
  if (saved.jiraProjectKey)    document.getElementById('jiraProjectKey').value    = saved.jiraProjectKey;
  if (saved.jiraIssueType) {
    const select = document.getElementById('jiraIssueType');
    const opt = document.createElement('option');
    opt.value = saved.jiraIssueType;
    opt.textContent = saved.jiraIssueType;
    select.insertBefore(opt, select.firstChild);
    select.value = saved.jiraIssueType;
  }
  if (saved.jiraAssignee)      document.getElementById('jiraAssignee').value      = saved.jiraAssignee;
  if (saved.jiraOAuthAssignee) document.getElementById('jiraAssigneeOAuth').value = saved.jiraOAuthAssignee;

  // Restore GitHub manual settings
  if (saved.githubRepo)        document.getElementById('githubRepo').value        = saved.githubRepo;
  if (saved.githubToken)       document.getElementById('githubToken').value       = saved.githubToken;
  if (saved.githubLabels)      document.getElementById('githubLabels').value      = saved.githubLabels;
  if (saved.githubAssignee)    document.getElementById('githubAssignee').value    = saved.githubAssignee;

  // Restore Network settings
  if (saved.verboseNetwork)    document.getElementById('verboseNetwork').checked   = saved.verboseNetwork;

  // Restore GitHub OAuth state
  if (saved.githubManualMode) {
    document.getElementById('githubManualMode').checked = true;
    document.getElementById('githubManualSection').classList.remove('hidden');
    document.getElementById('githubConnectSection').classList.add('hidden');
  } else if (saved.githubOAuthToken && saved.githubOAuthUser) {
    showGithubConnected(saved.githubOAuthUser.login, saved.githubOAuthUser.avatar_url);
    loadGithubRepos(saved.githubOAuthToken);
  }

  // ── Save settings on submit ──────────────────────────
  document.getElementById('settingsForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const btn = document.getElementById('saveBtn');
    btn.textContent = '⏳ Saving...';
    btn.disabled = true;

    await chrome.storage.sync.set({
      azureOrg:          document.getElementById('azureOrg').value.trim(),
      azureProject:      document.getElementById('azureProject').value.trim(),
      azurePat:          document.getElementById('azurePat').value.trim(),
      azureWorkItemType: document.getElementById('azureWorkItemType').value,
      azureAreaPath:     document.getElementById('azureAreaPath').value.trim(),
      azureAssignedTo:   document.getElementById('azureAssignedTo').value.trim(),
      azureManualMode:   document.getElementById('azureManualMode').checked,
      azureOAuthOrg:     document.getElementById('azureOrgSelect').value,
      azureOAuthProject: document.getElementById('azureProjectSelect').value,
      jiraDomain:        document.getElementById('jiraDomain').value.trim(),
      jiraEmail:         document.getElementById('jiraEmail').value.trim(),
      jiraToken:         document.getElementById('jiraToken').value.trim(),
      jiraProjectKey:    document.getElementById('jiraProjectKey').value.trim().toUpperCase(),
      jiraIssueType:     document.getElementById('jiraIssueType').value,
      jiraAssignee:      document.getElementById('jiraAssignee').value.trim(),
      jiraManualMode:    document.getElementById('jiraManualMode').checked,
      jiraOAuthCloudId:  document.getElementById('jiraSiteSelect').value,
      jiraOAuthProject:  document.getElementById('jiraProjectSelect').value,
      jiraOAuthIssueType: document.getElementById('jiraIssueTypeOAuth').value,
      jiraOAuthAssignee: document.getElementById('jiraAssigneeOAuth').value.trim(),
      githubRepo:        document.getElementById('githubRepo').value.trim(),
      githubToken:       document.getElementById('githubToken').value.trim(),
      githubLabels:      document.getElementById('githubLabels').value.trim(),
      githubAssignee:    document.getElementById('githubAssignee').value.trim(),
      githubManualMode:  document.getElementById('githubManualMode').checked,
      githubRepoFullName: document.getElementById('githubRepoSelect').value,
      verboseNetwork:    document.getElementById('verboseNetwork').checked
    });

    // Auto-set active provider for manual modes if none selected yet
    const current = await chrome.storage.sync.get(['activeProvider']);
    if (!current.activeProvider) {
      const azureManual = document.getElementById('azureManualMode').checked;
      const azureOrg    = document.getElementById('azureOrg').value.trim();
      const azureProj   = document.getElementById('azureProject').value.trim();
      const azurePat    = document.getElementById('azurePat').value.trim();
      const jiraDomain  = document.getElementById('jiraDomain').value.trim();
      const jiraEmail   = document.getElementById('jiraEmail').value.trim();
      const jiraToken   = document.getElementById('jiraToken').value.trim();
      const jiraKey     = document.getElementById('jiraProjectKey').value.trim();
      const ghManual    = document.getElementById('githubManualMode').checked;
      const ghRepo      = document.getElementById('githubRepo').value.trim();
      const ghToken     = document.getElementById('githubToken').value.trim();

      if (azureManual && azureOrg && azureProj && azurePat) {
        await setActiveProvider('azure');
      } else if (jiraDomain && jiraEmail && jiraToken && jiraKey) {
        await setActiveProvider('jira');
      } else if (ghManual && ghRepo && ghToken) {
        await setActiveProvider('github');
      }
    }

    btn.textContent = '💾 Save Settings';
    btn.disabled = false;

    const status = document.getElementById('saveStatus');
    status.classList.remove('hidden');
    setTimeout(() => status.classList.add('hidden'), 3500);
  });

  // ── Fetch Jira issue types ───────────────────────────
  document.getElementById('fetchIssueTypesBtn').addEventListener('click', async () => {
    const domain     = document.getElementById('jiraDomain').value.trim().replace(/\/$/, '').replace(/^https?:\/\//, '');
    const email      = document.getElementById('jiraEmail').value.trim();
    const token      = document.getElementById('jiraToken').value.trim();
    const projectKey = document.getElementById('jiraProjectKey').value.trim().toUpperCase();
    const statusEl   = document.getElementById('issueTypeStatus');
    const btn        = document.getElementById('fetchIssueTypesBtn');

    if (!domain || !email || !token || !projectKey) {
      statusEl.innerHTML = '⚠️ Fill in Domain, Email, Token, and Project Key first.';
      statusEl.style.color = '#ef4444';
      return;
    }

    btn.textContent = '...';
    btn.disabled = true;
    statusEl.innerHTML = 'Fetching issue types...';
    statusEl.style.color = '#94a3b8';

    try {
      const baseUrl = `https://${domain}`;
      const auth    = btoa(email + ':' + token);

      const res = await fetch(`${baseUrl}/rest/api/3/issue/createmeta/${projectKey}/issuetypes`, {
        headers: {
          'Authorization': 'Basic ' + auth,
          'Accept': 'application/json'
        }
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.errorMessages?.join(', ') || `HTTP ${res.status}`);
      }

      const data = await res.json();
      const types = data.issueTypes || data.values || [];

      if (types.length === 0) throw new Error('No issue types found for this project.');

      const select = document.getElementById('jiraIssueType');
      const currentVal = select.value;
      select.innerHTML = '';
      types.forEach(t => {
        const opt = document.createElement('option');
        opt.value = t.name;
        opt.textContent = t.name + (t.subtask ? ' (subtask)' : '');
        select.appendChild(opt);
      });

      if (currentVal && [...select.options].some(o => o.value === currentVal)) {
        select.value = currentVal;
      }

      statusEl.innerHTML = `✅ Loaded ${types.length} issue type${types.length !== 1 ? 's' : ''} from <strong>${projectKey}</strong>.`;
      statusEl.style.color = '#15803d';
    } catch (err) {
      statusEl.innerHTML = '❌ ' + err.message;
      statusEl.style.color = '#ef4444';
    } finally {
      btn.textContent = 'Load';
      btn.disabled = false;
    }
  });

  // ── Jira OAuth event listeners ────────────────────────
  document.getElementById('jiraConnectBtn').addEventListener('click', initiateJiraOAuth);
  document.getElementById('jiraDisconnectBtn').addEventListener('click', disconnectJira);

  document.getElementById('refreshJiraSitesBtn').addEventListener('click', async () => {
    const token = await getJiraTokenForSettings();
    if (token) await loadJiraSites(token);
  });

  document.getElementById('jiraSiteSelect').addEventListener('change', async (e) => {
    const cloudId = e.target.value;
    if (!cloudId) {
      document.getElementById('jiraProjectSelect').innerHTML = '<option value="">— Select a site first —</option>';
      document.getElementById('jiraIssueTypeOAuth').innerHTML = '<option value="">— Select a project first —</option>';
      return;
    }
    // Save cloudId, site name and site URL
    const opt = e.target.options[e.target.selectedIndex];
    await chrome.storage.sync.set({
      jiraOAuthCloudId:  cloudId,
      jiraOAuthSiteName: opt.textContent,
      jiraOAuthSiteUrl:  opt.dataset.url || ''
    });
    const token = await getJiraTokenForSettings();
    if (token) await loadJiraProjects(token, cloudId);
  });

  document.getElementById('jiraProjectSelect').addEventListener('change', async (e) => {
    const projectKey = e.target.value;
    if (!projectKey) {
      document.getElementById('jiraIssueTypeOAuth').innerHTML = '<option value="">— Select a project first —</option>';
      return;
    }
    const cloudId = document.getElementById('jiraSiteSelect').value;
    if (!cloudId) return;
    const token = await getJiraTokenForSettings();
    if (token) await loadJiraIssueTypesOAuth(token, cloudId, projectKey);
  });

  document.getElementById('loadIssueTypesOAuthBtn').addEventListener('click', async () => {
    const cloudId = document.getElementById('jiraSiteSelect').value;
    const projectKey = document.getElementById('jiraProjectSelect').value;
    if (!cloudId || !projectKey) return;
    const token = await getJiraTokenForSettings();
    if (token) await loadJiraIssueTypesOAuth(token, cloudId, projectKey);
  });

  document.getElementById('jiraManualMode').addEventListener('change', (e) => {
    const manual = e.target.checked;
    document.getElementById('jiraManualSection').classList.toggle('hidden', !manual);
    if (manual) {
      document.getElementById('jiraConnectSection').classList.add('hidden');
      document.getElementById('jiraOAuthStatus').classList.add('hidden');
      document.getElementById('jiraOAuthSection').classList.add('hidden');
    } else {
      chrome.storage.sync.get(['jiraOAuthToken', 'jiraOAuthUser'], async (saved) => {
        if (saved.jiraOAuthToken && saved.jiraOAuthUser) {
          showJiraConnected(saved.jiraOAuthUser.displayName, saved.jiraOAuthUser.email);
          const token = await getJiraTokenForSettings();
          if (token) await loadJiraSites(token);
        } else {
          showJiraDisconnected();
        }
      });
    }
  });

  // ── GitHub OAuth event listeners ─────────────────────
  document.getElementById('githubConnectBtn').addEventListener('click', initiateGithubOAuth);
  document.getElementById('githubDisconnectBtn').addEventListener('click', disconnectGithub);

  document.getElementById('refreshReposBtn').addEventListener('click', async () => {
    const saved = await chrome.storage.sync.get(['githubOAuthToken']);
    if (saved.githubOAuthToken) {
      await loadGithubRepos(saved.githubOAuthToken);
    }
  });

  document.getElementById('githubManualMode').addEventListener('change', (e) => {
    const manual = e.target.checked;
    document.getElementById('githubManualSection').classList.toggle('hidden', !manual);
    if (manual) {
      document.getElementById('githubConnectSection').classList.add('hidden');
      document.getElementById('githubOAuthStatus').classList.add('hidden');
      document.getElementById('githubRepoOAuthSection').classList.add('hidden');
    } else {
      chrome.storage.sync.get(['githubOAuthToken', 'githubOAuthUser'], (saved) => {
        if (saved.githubOAuthToken && saved.githubOAuthUser) {
          showGithubConnected(saved.githubOAuthUser.login, saved.githubOAuthUser.avatar_url);
          loadGithubRepos(saved.githubOAuthToken);
        } else {
          showGithubDisconnected();
        }
      });
    }
  });

  // ── Switch provider ───────────────────────────────────
  document.getElementById('switchProviderBtn').addEventListener('click', clearActiveProvider);

  // ── Provider selector buttons ─────────────────────────
  document.getElementById('pickAzureBtn').addEventListener('click', () => setActiveProvider('azure'));
  document.getElementById('pickJiraBtn').addEventListener('click',  () => setActiveProvider('jira'));
  document.getElementById('pickGithubBtn').addEventListener('click', () => setActiveProvider('github'));


  // ── Azure OAuth event listeners ──────────────────────
  document.getElementById('azureConnectBtn').addEventListener('click', initiateAzureOAuth);
  document.getElementById('azureDisconnectBtn').addEventListener('click', disconnectAzure);

  document.getElementById('refreshOrgsBtn').addEventListener('click', async () => {
    const token = await getAzureTokenForSettings();
    if (token) await loadAzureOrgs(token);
  });

  document.getElementById('azureOrgSelect').addEventListener('change', async (e) => {
    const org = e.target.value;
    if (!org) {
      document.getElementById('azureProjectSelect').innerHTML = '<option value="">— Select an organization first —</option>';
      return;
    }
    const token = await getAzureTokenForSettings();
    if (token) await loadAzureProjects(token, org);
  });

  document.getElementById('azurePatHelpToggle').addEventListener('click', () => {
    const panel = document.getElementById('azurePatHelp');
    const btn   = document.getElementById('azurePatHelpToggle');
    const hidden = panel.classList.toggle('hidden');
    btn.textContent = hidden ? 'How to create a PAT?' : 'Hide instructions';
  });

  document.getElementById('azureManualMode').addEventListener('change', (e) => {
    const manual = e.target.checked;
    document.getElementById('azureManualSection').classList.toggle('hidden', !manual);
    document.getElementById('azureOAuthOnlyFields').classList.toggle('hidden', manual);
    if (manual) {
      document.getElementById('azureConnectSection').classList.add('hidden');
      document.getElementById('azureOAuthStatus').classList.add('hidden');
      document.getElementById('azureOAuthSection').classList.add('hidden');
    } else {
      chrome.storage.sync.get(['azureOAuthToken', 'azureOAuthUser'], async (saved) => {
        if (saved.azureOAuthToken && saved.azureOAuthUser) {
          showAzureConnected(saved.azureOAuthUser.displayName, saved.azureOAuthUser.emailAddress);
          const token = await getAzureTokenForSettings();
          if (token) await loadAzureOrgs(token);
        } else {
          showAzureDisconnected();
        }
      });
    }
  });

  // ── Toggle password visibility ───────────────────────
  document.querySelectorAll('.toggle-visibility').forEach(button => {
    button.addEventListener('click', () => {
      const targetId = button.getAttribute('data-target');
      const input    = document.getElementById(targetId);
      if (input.type === 'password') {
        input.type = 'text';
        button.textContent = '🙈';
      } else {
        input.type = 'password';
        button.textContent = '👁';
      }
    });
  });
});
