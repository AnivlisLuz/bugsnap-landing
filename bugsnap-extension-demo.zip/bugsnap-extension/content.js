// content.js — Runs directly in the page's MAIN world (declared in manifest.json)
// "world": "MAIN" bypasses CSP restrictions on inline scripts.
// Captures console, ALL network requests (with timing), and CSP violations.

if (!window.__bugsnap_logs) {
  window.__bugsnap_logs = [];

  const _serialize = args => args.map(a => {
    try { return typeof a === 'object' ? JSON.stringify(a) : String(a); }
    catch (e) { return String(a); }
  }).join(' ');

  const _wrap = (type, orig) => function (...args) {
    window.__bugsnap_logs.push({ type, message: _serialize(args), time: new Date().toISOString() });
    orig(...args);
  };

  console.log   = _wrap('log',   console.log.bind(console));
  console.info  = _wrap('info',  console.info.bind(console));
  console.warn  = _wrap('warn',  console.warn.bind(console));
  console.error = _wrap('error', console.error.bind(console));
  console.debug = _wrap('debug', console.debug.bind(console));

  window.addEventListener('error', function (event) {
    window.__bugsnap_logs.push({
      type: 'uncaught',
      message: event.message + (event.filename ? ' at ' + event.filename + ':' + event.lineno : ''),
      time: new Date().toISOString()
    });
  });

  window.addEventListener('unhandledrejection', function (event) {
    window.__bugsnap_logs.push({
      type: 'promise',
      message: 'Unhandled Promise Rejection: ' + (event.reason?.message || String(event.reason)),
      time: new Date().toISOString()
    });
  });

  // ── Intercept fetch() — capture ALL requests with timing ─────────────────
  const _origFetch = window.fetch;
  window.fetch = async function (...args) {
    const req    = args[0];
    const url    = typeof req === 'string' ? req : (req?.url || String(req));
    const method = (typeof req === 'object' && req?.method) || args[1]?.method || 'GET';
    const t0     = Date.now();

    try {
      const response = await _origFetch.apply(this, args);
      const duration = Date.now() - t0;
      const isError  = !response.ok;

      const entry = {
        type:    isError ? 'network' : 'network_ok',
        message: method + ' ' + response.status + ' ' + response.statusText + ' — ' + url + ' (' + duration + 'ms)',
        time:    new Date().toISOString()
      };

      if (isError) {
        try {
          const bodyText = await response.clone().text();
          entry.body = bodyText.substring(0, 500);
        } catch (_) {
          entry.body = '(could not read response body)';
        }
      }

      window.__bugsnap_logs.push(entry);
      return response;
    } catch (err) {
      const duration = Date.now() - t0;
      window.__bugsnap_logs.push({
        type:    'network',
        message: method + ' ERR ' + err.message + ' — ' + url + ' (' + duration + 'ms)',
        time:    new Date().toISOString()
      });
      throw err;
    }
  };

  // ── Intercept XMLHttpRequest — capture ALL requests with timing ───────────
  const _origOpen = XMLHttpRequest.prototype.open;
  const _origSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__bugsnap_url    = url;
    this.__bugsnap_method = method;
    return _origOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    this.__bugsnap_t0 = Date.now();
    this.addEventListener('loadend', () => {
      const duration = Date.now() - (this.__bugsnap_t0 || Date.now());
      const isError  = this.status >= 400 || (this.status === 0 && this.readyState === 4);

      const entry = {
        type:    isError ? 'network' : 'network_ok',
        message: (this.__bugsnap_method || 'XHR') + ' ' + (this.status || 'ERR') + ' ' +
                 (this.statusText || 'Network Error') + ' — ' + (this.__bugsnap_url || '') +
                 ' (' + duration + 'ms)',
        time:    new Date().toISOString()
      };

      if (isError && this.responseText) {
        entry.body = this.responseText.substring(0, 500);
      }

      window.__bugsnap_logs.push(entry);
    });
    return _origSend.apply(this, args);
  };

  // ── Capture CSP violations ────────────────────────────────────────────────
  document.addEventListener('securitypolicyviolation', function (event) {
    window.__bugsnap_logs.push({
      type:    'csp',
      message: 'CSP violation: ' + event.violatedDirective + ' — blocked: ' + event.blockedURI,
      time:    new Date().toISOString()
    });
  });
}
